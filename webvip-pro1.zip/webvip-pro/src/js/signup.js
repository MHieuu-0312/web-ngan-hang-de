/* ========================================
   SIGNUP PAGE JAVASCRIPT (ĐÃ SỬA)
   ======================================== */

// BƯỚC 1:
// currentStep = 1 nghĩa là bước "Thông tin cá nhân" (formStep2)
// currentStep = 2 nghĩa là bước "Thiết lập tài khoản" (formStep3)
let currentStep = 1;
let selectedRole = 'student'; // Đã chọn vai trò mặc định (vì Step 1 đã bị xóa)

// BƯỚC 2: XÓA toàn bộ hàm selectRole. Nó không còn cần thiết.

// Update step indicator visual state
function updateStepIndicator() {
    // Vòng lặp này (1 đến 2) giờ đã khớp với 2 bước trên thanh chỉ báo HTML
    for (let i = 1; i <= 2; i++) {
        const step = document.getElementById(`step${i}`);
        const line = document.getElementById(`line${i}`);
 
         if (i < currentStep) {
            step.className = 'step completed';
            if (line) line.className = 'step-line completed';
        } else if (i === currentStep) {
            step.className = 'step current';
        } else {
            step.className = 'step pending';
        }
        }
}

// Show specific form step
function showStep(step) {
        document.querySelectorAll('.form-step').forEach(el => el.classList.remove('active'));
    
    // BƯỚC 3: SỬA LỖI MAPPING
    // Khi step = 1, ta hiển thị 'formStep2'
    // Khi step = 2, ta hiển thị 'formStep3'
    const formStepId = `formStep${step + 1}`; 
    document.getElementById(formStepId).classList.add('active');
}

// Move to next step
function nextStep() {
    if (validateCurrentStep()) {
        currentStep++; // Từ 1 lên 2
        updateStepIndicator();
        showStep(currentStep); // Hiển thị step 2 (formStep3)
    }
}

// Move to previous step
function prevStep() {
    currentStep--; // Từ 2 về 1
    updateStepIndicator();
    showStep(currentStep); // Hiển thị step 1 (formStep2)
}

// Validate current step data
function validateCurrentStep() {
    // BƯỚC 4: SỬA LOGIC KIỂM TRA
    // Giờ chỉ cần kiểm tra cho bước 1 (Thông tin cá nhân)
    if (currentStep === 1) {
    return validatePersonalInfo();
    }
    return true;
}

// Validate personal information (Step 2)
function validatePersonalInfo() {
    const name = document.getElementById('fullName').value;
    const email = document.getElementById('email').value;
    // BƯỚC 5: XÓA 'phone' vì nó không còn trong HTML

    let isValid = true;

    // Reset errors
    document.querySelectorAll('.error-message').forEach(el => el.style.display = 'none');

    // Validate name
    if (!name.trim()) {
        document.getElementById('nameError').style.display = 'block';
        isValid = false;
    }
    // Validate email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        document.getElementById('emailError').style.display = 'block';
        isValid = false;
    }


    return isValid;
}

// Validate final step (Step 3)
function validateFinalStep() {
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const terms = document.getElementById('terms').checked;

    let isValid = true;

    // Reset errors
    document.querySelectorAll('.error-message').forEach(el => el.style.display = 'none');

// Validate password strength
    if (password.length < 8 || !/[a-zA-Z]/.test(password) || !/\d/.test(password)) {
        document.getElementById('passwordError').style.display = 'block';
        isValid = false;
    }

    // Validate password match
    if (password !== confirmPassword) {
        document.getElementById('confirmPasswordError').style.display = 'block';
        isValid = false;
    }
    // Validate terms acceptance
    if (!terms) {
        document.getElementById('termsError').style.display = 'block';
        isValid = false;
    }

    return isValid;
}

// Toggle password visibility
function togglePassword(fieldId) {
    const input = document.getElementById(fieldId);
    const icon = document.getElementById(fieldId + 'Icon');

    if (input.type === 'password') {
        input.type = 'text';
        icon.className = 'fas fa-eye-slash text-gray-400';
    } else {
        input.type = 'password';
        icon.className = 'fas fa-eye text-gray-400';
    }
}

// Check password strength
function checkPasswordStrength() {
    const password = document.getElementById('password').value;
    const strengthBar = document.getElementById('strengthBar');
    const strengthText = document.getElementById('strengthText');

    let strength = 0;

    // Check length
    if (password.length >= 8) strength++;
    if (password.length >= 12) strength++;

    // Check for lowercase and uppercase
    if (/[a-z]/.test(password) && /[A-Z]/.test(password)) strength++;

    // Check for numbers
    if (/\d/.test(password)) strength++;

    // Check for special characters
    if (/[^a-zA-Z\d]/.test(password)) strength++;

// Update UI based on strength
    strengthBar.className = 'strength-bar';

    if (strength <= 1) {
        strengthBar.classList.add('strength-weak');
        strengthText.textContent = 'Yếu';
    } else if (strength === 2) {
        strengthBar.classList.add('strength-fair');
        strengthText.textContent = 'Trung bình';
    } else if (strength === 3 || strength === 4) {
        strengthBar.classList.add('strength-good');
        strengthText.textContent = 'Tốt';
    } else {
        strengthBar.classList.add('strength-strong');
        strengthText.textContent = 'Mạnh';
    }
}

// Initialize form when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // BƯỚC 7: Cập nhật chỉ báo ngay khi tải trang
    updateStepIndicator();

    const signupForm = document.getElementById('signupForm');
    if (signupForm) {
        signupForm.addEventListener('submit', function(e) {
            e.preventDefault();

            // Kiểm tra bước cuối cùng (mật khẩu, điều khoản)
            if (validateFinalStep()) {
                document.getElementById('successMessage').style.display = 'block';
                // Chờ 2 giây để hiển thị thông báo, sau đó chuyển hướng
                setTimeout(() => {
                window.location.href = 'student-dashboard.html';
                }, 2000); 
            }
        });
}
});