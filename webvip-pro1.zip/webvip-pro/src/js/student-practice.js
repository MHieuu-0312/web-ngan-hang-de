// ====================================
// STUDENT PRACTICE PAGE FUNCTIONALITY
// ====================================

// Study Modes
function startStudyMode(mode) {
    const modes = {
        flashcards: 'Bắt đầu học với flashcards! Đang chuyển hướng...',
        practice: 'Bắt đầu luyện tập! Chọn chủ đề bạn muốn luyện...',
        review: 'Ôn tập các câu đã làm sai! Đang tải...',
        challenge: 'Bắt đầu thử thách hàng ngày! Sẵn sàng chưa?'
    };
    
    alert(modes[mode]);
    
    setTimeout(() => {
        showAchievementNotification('Bắt đầu học tập!', 'Bạn nhận được 10 XP');
    }, 1000);
}

// Continue Practice
function continuePractice(subject) {
    const subjectNames = {
        math: 'Toán học',
        biology: 'Sinh học',
        literature: 'Ngữ văn'
    };
    
    alert(`Tiếp tục học ${subjectNames[subject]}! Đang tải bài tập tiếp theo...`);
    
    setTimeout(() => {
        showAchievementNotification('Tiếp tục học tập!', 'Bạn nhận được 5 XP');
    }, 500);
}

// Flashcards
function flipCard(card) {
    card.classList.toggle('flipped');
}

function viewAllFlashcards() {
    alert('Đang mở thư viện flashcards...');
}

// Achievement Notification
function showAchievementNotification(title, message) {
    const notification = document.getElementById('achievementNotification');
    notification.querySelector('p:first-child').textContent = title;
    notification.querySelector('p:last-child').textContent = message;
    
    notification.classList.add('show');
    
    setTimeout(() => {
        notification.classList.remove('show');
    }, 3000);
}

// ====================================
// INITIALIZATION
// ====================================

document.addEventListener('DOMContentLoaded', function() {
    // Initialize flashcard interactions
    const flashcards = document.querySelectorAll('.flashcard');
    flashcards.forEach((card, index) => {
        setTimeout(() => {
            card.addEventListener('mouseenter', () => {
                if (!card.classList.contains('flipped')) {
                    card.classList.add('flipped');
                }
            });
            
            card.addEventListener('mouseleave', () => {
                if (card.classList.contains('flipped')) {
                    setTimeout(() => {
                        card.classList.remove('flipped');
                    }, 1000);
                }
            });
        }, index * 200);
    });

    // Initialize fade-in animations
    setTimeout(() => {
        document.querySelectorAll('.fade-in').forEach((el, index) => {
            setTimeout(() => {
                el.style.opacity = '1';
                el.style.transform = 'translateY(0)';
            }, index * 100);
        });
    }, 100);
});

// Simulate daily goal progress
setInterval(() => {
    const goalElement = document.querySelector('.daily-goal h3');
    if (goalElement) {
        let currentGoal = parseInt(goalElement.textContent);
        if (currentGoal < 100) {
            currentGoal += Math.floor(Math.random() * 3) + 1;
            goalElement.textContent = Math.min(currentGoal, 100) + '%';
            
            if (currentGoal >= 100) {
                setTimeout(() => {
                    showAchievementNotification('Mục tiêu hoàn thành!', 'Bạn đã đạt mục tiêu học tập hôm nay +200 XP');
                }, 500);
            }
        }
    }
}, 10000);
