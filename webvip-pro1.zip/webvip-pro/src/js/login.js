/* ========================================
   LOGIN PAGE JAVASCRIPT
   ======================================== */

// Toggle password visibility
function togglePassword() {
    const passwordInput = document.getElementById('password');
    const passwordIcon = document.getElementById('passwordIcon');
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        passwordIcon.className = 'fas fa-eye-slash text-gray-400';
    } else {
        passwordInput.type = 'password';
        passwordIcon.className = 'fas fa-eye text-gray-400';
    }
}

// Validate email format
function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Validate password length
function validatePassword(password) {
    return password.length >= 6;
}

// Show/hide error messages
function showError(elementId, show) {
    const element = document.getElementById(elementId);
    if (element) {
        element.style.display = show ? 'block' : 'none';
    }
}

// Social login handler
function socialLogin(provider) {
    alert(`Đăng nhập bằng ${provider}. Tính năng đang được phát triển.`);
}

// Form submission handler
document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const emailInput = document.getElementById('email');
    
    // Auto-focus on email field
    if (emailInput) {
        emailInput.focus();
    }
    
    // Handle form submission
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            
            // Reset error messages
            showError('emailError', false);
            showError('passwordError', false);
            
            let isValid = true;
            
            // Validate email
            if (!validateEmail(email)) {
                showError('emailError', true);
                isValid = false;
            }
            
            // Validate password
            if (!validatePassword(password)) {
                showError('passwordError', true);
                isValid = false;
            }
            
            if (isValid) {
                // Show success message
                const successMsg = document.getElementById('successMessage');
                if (successMsg) {
                    successMsg.style.display = 'block';
                }
                
                // Simulate login and redirect
                setTimeout(() => {
                    // Redirect to student dashboard
                    window.location.href = 'student-dashboard.html';
                }, 1500);
            }
        });
    }
});
