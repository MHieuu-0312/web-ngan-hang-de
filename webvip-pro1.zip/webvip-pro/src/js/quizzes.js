// ====================================
// QUIZZES PAGE FUNCTIONALITY
// ====================================

// Filter functions
function filterByCategory(category) {
    const chips = document.querySelectorAll('.filter-chip');
    chips.forEach(chip => chip.classList.remove('active'));
    event.target.classList.add('active');
    
    const items = document.querySelectorAll('.quiz-item');
    items.forEach(item => {
        if (category === 'all' || item.dataset.category === category) {
            item.style.display = '';
        } else {
            item.style.display = 'none';
        }
    });
}

function filterByDifficulty(difficulty) {
    const items = document.querySelectorAll('.quiz-item');
    items.forEach(item => {
        if (difficulty === 'all' || item.dataset.difficulty === difficulty) {
            item.style.display = '';
        } else {
            item.style.display = 'none';
        }
    });
}

function filterByStatus(status) {
    const items = document.querySelectorAll('.quiz-item');
    items.forEach(item => {
        if (status === 'all' || item.dataset.status === status) {
            item.style.display = '';
        } else {
            item.style.display = 'none';
        }
    });
}

function filterQuizzes() {
    const searchInput = document.getElementById('searchInput').value.toLowerCase();
    const items = document.querySelectorAll('.quiz-item');
    
    items.forEach(item => {
        const title = item.querySelector('h3').textContent.toLowerCase();
        const description = item.querySelector('p').textContent.toLowerCase();
        
        if (title.includes(searchInput) || description.includes(searchInput)) {
            item.style.display = '';
        } else {
            item.style.display = 'none';
        }
    });
}

// View toggle
function toggleView(view) {
    const gridViewBtn = document.getElementById('gridViewBtn');
    const listViewBtn = document.getElementById('listViewBtn');
    const quizList = document.getElementById('quizList');
    
    if (view === 'grid') {
        gridViewBtn.classList.add('text-blue-600', 'bg-blue-50', 'border-blue-200');
        gridViewBtn.classList.remove('text-gray-600');
        listViewBtn.classList.remove('text-blue-600', 'bg-blue-50', 'border-blue-200');
        listViewBtn.classList.add('text-gray-600');
        quizList.classList.add('quiz-grid');
        quizList.classList.remove('space-y-4');
    } else {
        listViewBtn.classList.add('text-blue-600', 'bg-blue-50', 'border-blue-200');
        listViewBtn.classList.remove('text-gray-600');
        gridViewBtn.classList.remove('text-blue-600', 'bg-blue-50', 'border-blue-200');
        gridViewBtn.classList.add('text-gray-600');
        quizList.classList.remove('quiz-grid');
        quizList.classList.add('space-y-4');
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    // Fade in animations
    setTimeout(() => {
        document.querySelectorAll('.fade-in').forEach((el, index) => {
            setTimeout(() => {
                el.style.opacity = '1';
                el.style.transform = 'translateY(0)';
            }, index * 100);
        });
    }, 100);
});
