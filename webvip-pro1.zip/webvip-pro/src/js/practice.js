/* ========================================
   PRACTICE PAGE JAVASCRIPT
   Chức năng ôn luyện
   ======================================== */

// Practice state
let practiceState = {
    selectedSubject: null,
    selectedDifficulty: null,
    selectedTopics: new Set(),
    questionCount: 10
};

// Select subject
function selectSubject(subject) {
    practiceState.selectedSubject = subject;
    
    // Update UI
    document.querySelectorAll('.subject-card').forEach(card => {
        card.classList.remove('selected');
    });
    
    const selectedCard = document.querySelector(`[data-subject="${subject}"]`);
    if (selectedCard) {
        selectedCard.classList.add('selected');
    }
    
    updateStartButton();
}

// Select difficulty
function selectDifficulty(difficulty) {
    practiceState.selectedDifficulty = difficulty;
    
    // Update UI
    document.querySelectorAll('.difficulty-option').forEach(option => {
        option.classList.remove('selected');
    });
    
    const selectedOption = document.querySelector(`[data-difficulty="${difficulty}"]`);
    if (selectedOption) {
        selectedOption.classList.add('selected');
    }
    
    updateStartButton();
}

// Toggle topic selection
function toggleTopic(topicId) {
    if (practiceState.selectedTopics.has(topicId)) {
        practiceState.selectedTopics.delete(topicId);
    } else {
        practiceState.selectedTopics.add(topicId);
    }
    
    // Update UI
    const topicCard = document.querySelector(`[data-topic="${topicId}"]`);
    if (topicCard) {
        topicCard.classList.toggle('selected');
    }
    
    updateStartButton();
}

// Update question count
function updateQuestionCount(count) {
    practiceState.questionCount = count;
    const display = document.getElementById('questionCountDisplay');
    if (display) {
        display.textContent = count;
    }
}

// Update start button state
function updateStartButton() {
    const startBtn = document.getElementById('startPracticeBtn');
    if (!startBtn) return;
    
    const canStart = practiceState.selectedSubject && 
                     practiceState.selectedDifficulty && 
                     practiceState.selectedTopics.size > 0;
    
    startBtn.disabled = !canStart;
    startBtn.classList.toggle('opacity-50', !canStart);
    startBtn.classList.toggle('cursor-not-allowed', !canStart);
}

// Start practice session
function startPractice() {
    if (!practiceState.selectedSubject || !practiceState.selectedDifficulty || practiceState.selectedTopics.size === 0) {
        alert('Vui lòng chọn đầy đủ thông tin để bắt đầu ôn luyện!');
        return;
    }
    
    // Save practice settings to sessionStorage
    sessionStorage.setItem('practiceSettings', JSON.stringify(practiceState));
    
    // Redirect to quiz taking page
    window.location.href = 'quiz-taking.html?mode=practice';
}

// Reset selections
function resetPractice() {
    practiceState = {
        selectedSubject: null,
        selectedDifficulty: null,
        selectedTopics: new Set(),
        questionCount: 10
    };
    
    // Reset UI
    document.querySelectorAll('.subject-card, .difficulty-option, .topic-card').forEach(el => {
        el.classList.remove('selected');
    });
    
    updateQuestionCount(10);
    updateStartButton();
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    // Load saved practice settings if any
    const saved = sessionStorage.getItem('practiceSettings');
    if (saved) {
        try {
            const settings = JSON.parse(saved);
            // Restore selections if needed
        } catch (e) {
            console.error('Failed to load practice settings:', e);
        }
    }
    
    updateStartButton();
    console.log('Practice page initialized');
});
