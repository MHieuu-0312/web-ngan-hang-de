// quiz-results.js - JavaScript cho trang kết quả bài kiểm tra

// Results data (would normally come from previous page or API)
let results = {
    totalQuestions: 20,
    correctAnswers: 17,
    incorrectAnswers: 2,
    unanswered: 1,
    score: 8.5,
    timeSpent: 1530, // seconds
    percentage: 85,
    rank: 3,
    totalStudents: 45,
    classAverage: 7.2,
    questions: []
};

// Sample questions for review
const sampleQuestions = [
    {
        id: 1,
        text: "Giải phương trình sau: 2x + 5 = 13",
        options: ["x = 4", "x = 5", "x = 6", "x = 8"],
        correct: 0,
        userAnswer: 0,
        isCorrect: true,
        explanation: "Để giải phương trình 2x + 5 = 13, ta trừ 5 ở cả hai vế: 2x = 8, sau đó chia cho 2: x = 4."
    },
    {
        id: 2,
        text: "Tìm giá trị của x trong phương trình: 3x - 7 = 14",
        options: ["x = 5", "x = 6", "x = 7", "x = 8"],
        correct: 2,
        userAnswer: 1,
        isCorrect: false,
        explanation: "3x - 7 = 14 → 3x = 21 → x = 7. Đáp án đúng là C."
    },
    {
        id: 3,
        text: "Nghiệm của phương trình x² - 5x + 6 = 0 là:",
        options: ["x = 1, x = 6", "x = 2, x = 3", "x = -2, x = -3", "x = 1, x = -6"],
        correct: 1,
        userAnswer: null,
        isCorrect: false,
        explanation: "Phân tích thành nhân tử: (x-2)(x-3) = 0, do đó x = 2 hoặc x = 3."
    }
];

// Initialize results page
function initResults() {
    // Try to get results from localStorage (from quiz page)
    const storedResults = localStorage.getItem('quizResults');
    if (storedResults) {
        results = JSON.parse(storedResults);
    } else {
        // Use sample data if no stored results
        results.questions = sampleQuestions;
    }

    updateResultsDisplay();
    renderChart();
    generateAchievements();
    renderQuestionsReview();
    createConfetti();
}

// Update results display
function updateResultsDisplay() {
    // Set completion time
    document.getElementById('completionTime').textContent = new Date().toLocaleString('vi-VN');

    // Update score and stats
    document.getElementById('finalScore').textContent = results.score;
    document.getElementById('correctAnswers').textContent = results.correctAnswers;
    document.getElementById('incorrectAnswers').textContent = results.incorrectAnswers || (results.totalQuestions - results.correctAnswers);
    document.getElementById('unansweredQuestions').textContent = results.unanswered || 0;

    // Format time spent
    const minutes = Math.floor(results.timeSpent / 60);
    const seconds = results.timeSpent % 60;
    document.getElementById('timeSpent').textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;

    // Update score circle
    const percentage = (results.correctAnswers / results.totalQuestions) * 100;
    const offset = 377 - (percentage / 100) * 377;
    document.getElementById('scoreCircle').style.setProperty('--score-offset', offset);

    // Update performance level
    let level, color;
    if (percentage >= 90) {
        level = 'Xuất sắc';
        color = '#16a34a';
    } else if (percentage >= 80) {
        level = 'Giỏi';
        color = '#2563eb';
    } else if (percentage >= 70) {
        level = 'Khá';
        color = '#f59e0b';
    } else {
        level = 'Cần cải thiện';
        color = '#dc2626';
    }

    document.getElementById('performanceLevel').textContent = level;
    document.getElementById('scoreCircle').style.stroke = color;

    // Update performance indicator position
    setTimeout(() => {
        const indicator = document.getElementById('performanceIndicator');
        indicator.style.left = `${percentage}%`;
    }, 1000);

    // Update congratulations message
    const message = document.getElementById('congratsMessage');
    if (percentage >= 90) {
        message.textContent = '🎉 Xuất sắc! Bạn đã làm bài rất tốt!';
        message.classList.add('celebration-text');
    } else if (percentage >= 80) {
        message.textContent = '👏 Tốt lắm! Kết quả rất ấn tượng!';
    } else if (percentage >= 70) {
        message.textContent = '👍 Khá tốt! Hãy tiếp tục cố gắng!';
    } else {
        message.textContent = '💪 Đừng nản lòng! Hãy ôn tập và thử lại!';
    }
}

// Render chart
function renderChart() {
    const ctx = document.getElementById('resultChart').getContext('2d');
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Đúng', 'Sai', 'Chưa trả lời'],
            datasets: [{
                data: [results.correctAnswers, results.incorrectAnswers || 0, results.unanswered || 0],
                backgroundColor: ['#16a34a', '#dc2626', '#f59e0b'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

// Generate achievements
function generateAchievements() {
    const achievements = [];
    const percentage = (results.correctAnswers / results.totalQuestions) * 100;

    if (percentage >= 90) {
        achievements.push({ icon: 'fas fa-trophy', text: 'Điểm cao nhất', color: 'bg-yellow-500' });
    }
    if (percentage >= 80) {
        achievements.push({ icon: 'fas fa-star', text: 'Xuất sắc', color: 'bg-blue-500' });
    }
    if (results.timeSpent < 1200) { // Less than 20 minutes
        achievements.push({ icon: 'fas fa-bolt', text: 'Tốc độ cao', color: 'bg-purple-500' });
    }
    if (results.correctAnswers >= 15) {
        achievements.push({ icon: 'fas fa-bullseye', text: 'Chính xác cao', color: 'bg-green-500' });
    }
    if (results.rank <= 5) {
        achievements.push({ icon: 'fas fa-medal', text: 'Top 5 lớp', color: 'bg-orange-500' });
    }

    const container = document.getElementById('achievementsList');
    achievements.forEach((achievement, index) => {
        setTimeout(() => {
            const badge = document.createElement('div');
            badge.className = `achievement-badge ${achievement.color}`;
            badge.innerHTML = `<i class="${achievement.icon} mr-2"></i>${achievement.text}`;
            container.appendChild(badge);
        }, index * 300);
    });
}

// Render questions review
function renderQuestionsReview() {
    const container = document.getElementById('questionsReview');
    const questions = results.questions || sampleQuestions;

    questions.forEach((question, index) => {
        const questionDiv = document.createElement('div');
        questionDiv.className = 'question-review';
        
        let statusClass, statusIcon, statusText;
        if (question.userAnswer === null) {
            statusClass = 'answer-not-answered';
            statusIcon = 'fas fa-question-circle text-yellow-600';
            statusText = 'Chưa trả lời';
        } else if (question.isCorrect) {
            statusClass = 'answer-correct';
            statusIcon = 'fas fa-check-circle text-green-600';
            statusText = 'Đúng';
        } else {
            statusClass = 'answer-incorrect';
            statusIcon = 'fas fa-times-circle text-red-600';
            statusText = 'Sai';
        }

        questionDiv.innerHTML = `
            <div class="p-6 rounded-lg ${statusClass}">
                <div class="flex items-start justify-between mb-4">
                    <h4 class="text-lg font-semibold text-gray-900">Câu ${index + 1}</h4>
                    <div class="flex items-center">
                        <i class="${statusIcon} mr-2"></i>
                        <span class="font-medium">${statusText}</span>
                    </div>
                </div>
                
                <p class="text-gray-700 mb-4">${question.text}</p>
                
                <div class="space-y-2">
                    ${question.options.map((option, i) => {
                        let optionClass = 'option-not-selected';
                        let icon = '';
                        
                        if (i === question.correct) {
                            optionClass = 'option-correct';
                            icon = '<i class="fas fa-check mr-2"></i>';
                        } else if (i === question.userAnswer && question.userAnswer !== question.correct) {
                            optionClass = 'option-incorrect';
                            icon = '<i class="fas fa-times mr-2"></i>';
                        }
                        
                        return `
                            <div class="flex items-center p-3 rounded-lg ${optionClass}">
                                <span class="w-6 h-6 rounded-full flex items-center justify-center mr-3 text-sm font-medium">
                                    ${String.fromCharCode(65 + i)}
                                </span>
                                ${icon}
                                <span>${option}</span>
                            </div>
                        `;
                    }).join('')}
                </div>
                
                ${question.explanation ? `
                    <div class="mt-4 p-4 bg-blue-50 rounded-lg">
                        <h5 class="font-medium text-blue-900 mb-2">
                            <i class="fas fa-lightbulb mr-2"></i>
                            Giải thích
                        </h5>
                        <p class="text-blue-800">${question.explanation}</p>
                    </div>
                ` : ''}
            </div>
        `;
        
        container.appendChild(questionDiv);
    });
}

// Create confetti effect for high scores
function createConfetti() {
    const percentage = (results.correctAnswers / results.totalQuestions) * 100;
    if (percentage >= 90) {
        for (let i = 0; i < 50; i++) {
            setTimeout(() => {
                const confetti = document.createElement('div');
                confetti.className = 'confetti';
                confetti.style.left = Math.random() * 100 + 'vw';
                confetti.style.animationDelay = Math.random() * 3 + 's';
                confetti.style.backgroundColor = ['#f59e0b', '#3b82f6', '#ef4444', '#10b981'][Math.floor(Math.random() * 4)];
                document.body.appendChild(confetti);
                
                setTimeout(() => {
                    confetti.remove();
                }, 3000);
            }, i * 50);
        }
    }
}

// Utility functions
function showAllQuestions() {
    document.querySelectorAll('.question-review').forEach(q => q.style.display = 'block');
}

function showIncorrectOnly() {
    document.querySelectorAll('.question-review').forEach(q => {
        if (q.querySelector('.answer-incorrect') || q.querySelector('.answer-not-answered')) {
            q.style.display = 'block';
        } else {
            q.style.display = 'none';
        }
    });
}

function printResults() {
    window.print();
}

function shareResults() {
    if (navigator.share) {
        navigator.share({
            title: 'Kết quả bài kiểm tra của tôi',
            text: `Tôi đã đạt ${results.score}/10 điểm trong bài kiểm tra Đại số cơ bản!`,
            url: window.location.href
        });
    } else {
        // Fallback for browsers that don't support native sharing
        const text = `Tôi đã đạt ${results.score}/10 điểm trong bài kiểm tra Đại số cơ bản!`;
        navigator.clipboard.writeText(text).then(() => {
            alert('Đã sao chép kết quả vào clipboard!');
        });
    }
}

function retakeQuiz() {
    if (confirm('Bạn có muốn làm lại bài kiểm tra này không?')) {
        localStorage.removeItem('quizResults');
        window.location.href = 'quiz-taking.html';
    }
}

// Add print styles
function addPrintStyles() {
    const printStyles = `
        @media print {
            .no-print { display: none !important; }
            body { background: white !important; }
            .card { box-shadow: none !important; border: 1px solid #ccc; }
        }
    `;
    const styleSheet = document.createElement('style');
    styleSheet.textContent = printStyles;
    document.head.appendChild(styleSheet);
}

// Add no-print class to elements
function setupPrintableElements() {
    document.querySelector('header').classList.add('no-print');
    document.querySelectorAll('.btn-primary, .btn-secondary').forEach(btn => {
        btn.classList.add('no-print');
    });
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    initResults();
    addPrintStyles();
    setupPrintableElements();
});
