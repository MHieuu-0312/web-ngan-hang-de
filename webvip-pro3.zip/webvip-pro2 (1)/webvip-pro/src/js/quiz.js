/**
 * QUIZ JAVASCRIPT
 * Quiz taking and results functionality
 */

// ==========================================
// QUIZ STATE
// ==========================================
let quizState = {
    currentQuestion: 0,
    answers: {},
    markedForReview: new Set(),
    timeRemaining: 1800, // 30 minutes in seconds
    timerInterval: null
};

// ==========================================
// TIMER FUNCTIONS
// ==========================================
function startTimer() {
    const timerDisplay = document.getElementById('timer');
    if (!timerDisplay) return;
    
    quizState.timerInterval = setInterval(() => {
        quizState.timeRemaining--;
        
        const minutes = Math.floor(quizState.timeRemaining / 60);
        const seconds = quizState.timeRemaining % 60;
        
        timerDisplay.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
        
        // Warning when less than 5 minutes
        if (quizState.timeRemaining <= 300) {
            timerDisplay.classList.add('warning');
        }
        
        // Auto-submit when time's up
        if (quizState.timeRemaining <= 0) {
            clearInterval(quizState.timerInterval);
            submitQuiz();
        }
    }, 1000);
}

function stopTimer() {
    if (quizState.timerInterval) {
        clearInterval(quizState.timerInterval);
    }
}

// ==========================================
// NAVIGATION FUNCTIONS
// ==========================================
function goToQuestion(questionNumber) {
    quizState.currentQuestion = questionNumber;
    updateQuestionDisplay();
    updateNavigationButtons();
    updateProgress();
}

function nextQuestion() {
    const totalQuestions = document.querySelectorAll('.question-nav-btn').length;
    if (quizState.currentQuestion < totalQuestions - 1) {
        quizState.currentQuestion++;
        updateQuestionDisplay();
        updateNavigationButtons();
        updateProgress();
    }
}

function previousQuestion() {
    if (quizState.currentQuestion > 0) {
        quizState.currentQuestion--;
        updateQuestionDisplay();
        updateNavigationButtons();
        updateProgress();
    }
}

// ==========================================
// ANSWER SELECTION
// ==========================================
function selectAnswer(questionId, answerId) {
    quizState.answers[questionId] = answerId;
    
    // Update UI
    const answerOptions = document.querySelectorAll('.answer-option');
    answerOptions.forEach(option => {
        option.classList.remove('selected');
    });
    
    const selectedOption = document.querySelector(`[data-answer-id="${answerId}"]`);
    if (selectedOption) {
        selectedOption.classList.add('selected');
    }
    
    // Update navigation button
    updateNavigationButtons();
}

// ==========================================
// MARK FOR REVIEW
// ==========================================
function toggleMarkForReview() {
    const currentQ = quizState.currentQuestion;
    
    if (quizState.markedForReview.has(currentQ)) {
        quizState.markedForReview.delete(currentQ);
    } else {
        quizState.markedForReview.add(currentQ);
    }
    
    updateNavigationButtons();
}

// ==========================================
// UPDATE UI FUNCTIONS
// ==========================================
function updateQuestionDisplay() {
    // Hide all questions
    const questions = document.querySelectorAll('[data-question]');
    questions.forEach(q => q.classList.add('hidden'));
    
    // Show current question
    const current = document.querySelector(`[data-question="${quizState.currentQuestion}"]`);
    if (current) {
        current.classList.remove('hidden');
    }
}

function updateNavigationButtons() {
    const navButtons = document.querySelectorAll('.question-nav-btn');
    
    navButtons.forEach((btn, index) => {
        btn.classList.remove('active', 'answered', 'marked');
        
        if (index === quizState.currentQuestion) {
            btn.classList.add('active');
        }
        
        if (quizState.answers[index] !== undefined) {
            btn.classList.add('answered');
        }
        
        if (quizState.markedForReview.has(index)) {
            btn.classList.add('marked');
        }
    });
}

function updateProgress() {
    const progressFill = document.querySelector('.quiz-progress-fill');
    const totalQuestions = document.querySelectorAll('.question-nav-btn').length;
    const progress = (quizState.currentQuestion + 1) / totalQuestions * 100;
    
    if (progressFill) {
        progressFill.style.width = `${progress}%`;
    }
}

// ==========================================
// SUBMIT QUIZ
// ==========================================
function submitQuiz() {
    const answeredCount = Object.keys(quizState.answers).length;
    const totalQuestions = document.querySelectorAll('.question-nav-btn').length;
    
    const confirmed = confirm(
        `Bạn đã trả lời ${answeredCount}/${totalQuestions} câu hỏi.\n\n` +
        `Bạn có chắc muốn nộp bài?`
    );
    
    if (confirmed) {
        stopTimer();
        
        // In real app, this would submit to server
        console.log('Quiz submitted:', quizState);
        
        // Redirect to results page
        window.location.href = 'quiz-results.html';
    }
}

// ==========================================
// INITIALIZE QUIZ
// ==========================================
document.addEventListener('DOMContentLoaded', function() {
    // Start timer if on quiz page
    if (document.getElementById('timer')) {
        startTimer();
    }
    
    // Initialize navigation
    updateQuestionDisplay();
    updateNavigationButtons();
    updateProgress();
    
    console.log('Quiz initialized!');
});

// ==========================================
// CLEANUP ON PAGE UNLOAD
// ==========================================
window.addEventListener('beforeunload', function() {
    stopTimer();
});
