
        let currentView = 'list';
        let currentFilters = {
            category: 'all',
            difficulty: 'all',
            status: 'all',
            search: ''
        };

        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('sidebarOverlay');
            
            sidebar.classList.toggle('sidebar-hidden');
            overlay.classList.toggle('hidden');
        }

        function toggleView(view) {
            currentView = view;
            const quizList = document.getElementById('quizList');
            const quizGrid = document.getElementById('quizGrid');
            const listBtn = document.getElementById('listViewBtn');
            const gridBtn = document.getElementById('gridViewBtn');

            if (view === 'grid') {
                quizList.classList.add('hidden');
                quizGrid.classList.remove('hidden');
                listBtn.className = 'p-2 text-gray-600 hover:text-blue-600 border border-gray-300 rounded-lg';
                gridBtn.className = 'p-2 text-blue-600 bg-blue-50 border border-blue-200 rounded-lg';
                generateGridView();
            } else {
                quizList.classList.remove('hidden');
                quizGrid.classList.add('hidden');
                listBtn.className = 'p-2 text-blue-600 bg-blue-50 border border-blue-200 rounded-lg';
                gridBtn.className = 'p-2 text-gray-600 hover:text-blue-600 border border-gray-300 rounded-lg';
            }
        }

        function generateGridView() {
            const quizGrid = document.getElementById('quizGrid');
            const quizItems = document.querySelectorAll('.quiz-item');
            
            quizGrid.innerHTML = '';
            
            quizItems.forEach(item => {
                if (item.style.display !== 'none') {
                    const gridItem = createGridItem(item);
                    quizGrid.appendChild(gridItem);
                }
            });
        }

        function createGridItem(listItem) {
            const category = listItem.dataset.category;
            const difficulty = listItem.dataset.difficulty;
            const status = listItem.dataset.status || 'available';
            const title = listItem.querySelector('h3').textContent;
            const description = listItem.querySelector('p').textContent;
            const timeText = listItem.querySelector('.fa-clock').parentNode.textContent;
            const questionText = listItem.querySelector('.fa-question-circle').parentNode.textContent;
            const gridItem = document.createElement('div');
            gridItem.className = 'card p-6 hover-scale';
            
            // Get appropriate icon and color
            let iconClass, colorClass;
            switch(category) {
                case 'math':
                    iconClass = 'fas fa-calculator';
                    colorClass = 'bg-blue-500';
                    break;
                case 'physics':
                    iconClass = 'fas fa-atom';
                    colorClass = 'bg-purple-500';
                    break;
                case 'chemistry':
                    iconClass = 'fas fa-flask';
                    colorClass = 'bg-green-500'; 
                    break;
                case 'english':
                    iconClass = 'fas fa-globe';
                    colorClass = 'bg-red-500';
                    break;
                default:
                    iconClass = 'fas fa-clipboard-list';
                    colorClass = 'bg-gray-500';
            }
            
            gridItem.innerHTML = `
                <div class="flex items-center justify-between mb-4">
                    <div class="subject-icon ${colorClass}">
                        <i class="${iconClass}"></i>
                    </div>
                    <div class="flex space-x-2">
                        <span class="quiz-difficulty difficulty-${difficulty}">${difficulty === 'easy' ? 'Dễ' : difficulty === 'medium' ? 'Trung bình' : 'Khó'}</span>
                        ${status === 'completed' ? `<span class="quiz-status status-completed">Đã hoàn thành</span>` : ''}
                    </div>
                </div>
                <h3 class="text-lg font-bold text-gray-900 mb-2">${title}</h3>
                <p class="text-gray-600 text-sm mb-4">${description}</p>
                <div class="flex items-center justify-between text-sm text-gray-500 mb-4">
                    <span><i class="fas fa-clock mr-1"></i> ${timeText.trim().split(' ')[0]} phút</span>
                    <span><i class="fas fa-question-circle mr-1"></i> ${questionText.trim().split(' ')[0]} câu</span>
                    
                    </div>
                ${status === 'available' ? 
                    '<a href="quiz-taking.html" class="btn-primary w-full justify-center"><i class="fas fa-play mr-2"></i>Bắt đầu làm bài</a>' :
                status === 'completed' ?
                    '<div class="flex space-x-2"><a href="quiz-results.html" class="btn-secondary flex-1 justify-center"><i class="fas fa-eye mr-2"></i>Kết quả</a><a href="quiz-taking.html" class="btn-primary flex-1 justify-center"><i class="fas fa-redo mr-2"></i>Làm lại</a></div>' :
                    '<button class="btn-secondary opacity-50 cursor-not-allowed w-full justify-center" disabled><i class="fas fa-lock mr-2"></i>Khóa</button>'
                }
            `;
            
            return gridItem;
        }

        function filterByCategory(category) {
            currentFilters.category = category;
            
            // Update active filter chip
            document.querySelectorAll('.filter-chip').forEach(chip => {
                chip.classList.remove('active');
            });
            event.target.classList.add('active');
            
            applyFilters();
        }

        function filterByDifficulty(difficulty) {
            currentFilters.difficulty = difficulty;
            applyFilters();
        }

        function filterByStatus(status) {
            currentFilters.status = status;
            applyFilters();
        }

        function filterQuizzes() {
            currentFilters.search = document.getElementById('searchInput').value.toLowerCase();
            applyFilters();
        }

        function applyFilters() {
            const quizItems = document.querySelectorAll('.quiz-item');
            
            quizItems.forEach(item => {
                const category = item.dataset.category;
                const difficulty = item.dataset.difficulty;
                const status = item.dataset.status;
                const title = item.querySelector('h3').textContent.toLowerCase();
                const description = item.querySelector('p').textContent.toLowerCase();
                
                const matchesCategory = currentFilters.category === 'all' || category === currentFilters.category;
                const matchesDifficulty = currentFilters.difficulty === 'all' || difficulty === currentFilters.difficulty;
                const matchesStatus = currentFilters.status === 'all' || status === currentFilters.status;
                const matchesSearch = currentFilters.search === '' || 
                    title.includes(currentFilters.search) || 
                    description.includes(currentFilters.search);
                
                if (matchesCategory && matchesDifficulty && matchesStatus && matchesSearch) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
            
            // Update grid view if active
            if (currentView === 'grid') {
                generateGridView();
            }
        }

        // Close sidebar when clicking outside on mobile
        window.addEventListener('resize', function() {
            if (window.innerWidth >= 768) {
                document.getElementById('sidebar').classList.remove('sidebar-hidden');
                document.getElementById('sidebarOverlay').classList.add('hidden');
            }
        });

        // Initialize animations
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(() => {
                document.querySelectorAll('.fade-in').forEach((el, index) => {
                    setTimeout(() => {
                        el.style.opacity = '1';
                        el.style.transform = 'translateY(0)';
                    }, index * 100);
                });
            }, 100);
        })