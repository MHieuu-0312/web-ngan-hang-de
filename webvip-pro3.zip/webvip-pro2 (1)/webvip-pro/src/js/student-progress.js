// student-progress.js - JavaScript cho trang tiến độ học tập

function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    
    sidebar.classList.toggle('sidebar-hidden');
    overlay.classList.toggle('hidden');
}

// Initialize weekly activity chart
function initWeeklyChart() {
    const ctx = document.getElementById('weeklyChart').getContext('2d');
    const weeklyChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'],
            datasets: [{
                label: 'Phút học',
                data: [45, 60, 30, 90, 75, 40, 50],
                backgroundColor: [
                    '#3b82f6', '#10b981', '#f59e0b', '#ef4444', 
                    '#8b5cf6', '#06b6d4', '#84cc16'
                ],
                borderRadius: 6,
                borderSkipped: false,
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Phút'
                    }
                }
            }
        }
    });
}

// Animate skill meters on load
function animateSkillMeters() {
    setTimeout(() => {
        const skillFills = document.querySelectorAll('.skill-fill');
        skillFills.forEach((fill, index) => {
            setTimeout(() => {
                const width = fill.style.width;
                fill.style.width = '0%';
                setTimeout(() => {
                    fill.style.width = width;
                }, 100);
            }, index * 200);
        });
    }, 500);
}

// Animate XP bar
function animateXPBar() {
    setTimeout(() => {
        const xpFill = document.querySelector('.xp-fill');
        const targetWidth = xpFill.style.width;
        xpFill.style.width = '0%';
        setTimeout(() => {
            xpFill.style.width = targetWidth;
        }, 1000);
    }, 800);
}

// Close sidebar when clicking outside on mobile
window.addEventListener('resize', function() {
    if (window.innerWidth >= 768) {
        document.getElementById('sidebar').classList.remove('sidebar-hidden');
        document.getElementById('sidebarOverlay').classList.add('hidden');
    }
});

// Initialize animations
function initFadeInAnimations() {
    setTimeout(() => {
        document.querySelectorAll('.fade-in').forEach((el, index) => {
            setTimeout(() => {
                el.style.opacity = '1';
                el.style.transform = 'translateY(0)';
            }, index * 100);
        });
    }, 100);
}

// Achievement unlock simulation
function initAchievementAnimation() {
    setTimeout(() => {
        const newAchievement = document.querySelector('.achievement-card-unlocked');
        if (newAchievement) {
            newAchievement.style.animation = 'bounce 0.5s ease-out';
        }
    }, 2000);
}

// Initialize all functions when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initWeeklyChart();
    animateSkillMeters();
    animateXPBar();
    initFadeInAnimations();
    initAchievementAnimation();
});
