/* ========================================
   STUDENT COMMON JAVASCRIPT
   Shared functionality for all student pages
   ======================================== */

// Sidebar toggle for mobile
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    if (sidebar) {
        sidebar.classList.toggle('sidebar-hidden');
    }
}

// Filter quizzes by search input
function filterQuizzes() {
    const searchInput = document.getElementById('searchInput');
    if (!searchInput) return;
    
    const searchTerm = searchInput.value.toLowerCase();
    const quizItems = document.querySelectorAll('.quiz-item');
    
    quizItems.forEach(item => {
        const title = item.querySelector('h3').textContent.toLowerCase();
        const description = item.querySelector('p').textContent.toLowerCase();
        
        if (title.includes(searchTerm) || description.includes(searchTerm)) {
            item.style.display = '';
        } else {
            item.style.display = 'none';
        }
    });
}

// Filter by category
function filterByCategory(category) {
    const quizItems = document.querySelectorAll('.quiz-item');
    const filterChips = document.querySelectorAll('.filter-chip');
    
    // Update active filter chip
    filterChips.forEach(chip => {
        chip.classList.remove('active');
        if (chip.textContent.toLowerCase().includes(category) || category === 'all') {
            chip.classList.add('active');
        }
    });
    
    // Filter quiz items
    quizItems.forEach(item => {
        if (category === 'all' || item.dataset.category === category) {
            item.style.display = '';
        } else {
            item.style.display = 'none';
        }
    });
}

// Filter by difficulty
function filterByDifficulty(difficulty) {
    const quizItems = document.querySelectorAll('.quiz-item');
    
    quizItems.forEach(item => {
        if (difficulty === 'all' || item.dataset.difficulty === difficulty) {
            item.style.display = '';
        } else {
            item.style.display = 'none';
        }
    });
}

// Filter by status
function filterByStatus(status) {
    const quizItems = document.querySelectorAll('.quiz-item');
    
    quizItems.forEach(item => {
        if (status === 'all' || item.dataset.status === status) {
            item.style.display = '';
        } else {
            item.style.display = 'none';
        }
    });
}

// Toggle view between grid and list
function toggleView(viewType) {
    const quizList = document.getElementById('quizList');
    const gridViewBtn = document.getElementById('gridViewBtn');
    const listViewBtn = document.getElementById('listViewBtn');
    
    if (!quizList) return;
    
    if (viewType === 'grid') {
        quizList.classList.remove('space-y-4');
        quizList.classList.add('grid', 'grid-cols-1', 'md:grid-cols-2', 'lg:grid-cols-3', 'gap-6');
        
        gridViewBtn.classList.add('text-blue-600', 'bg-blue-50', 'border-blue-200');
        gridViewBtn.classList.remove('text-gray-600', 'border-gray-300');
        listViewBtn.classList.remove('text-blue-600', 'bg-blue-50', 'border-blue-200');
        listViewBtn.classList.add('text-gray-600', 'border-gray-300');
    } else {
        quizList.classList.add('space-y-4');
        quizList.classList.remove('grid', 'grid-cols-1', 'md:grid-cols-2', 'lg:grid-cols-3', 'gap-6');
        
        listViewBtn.classList.add('text-blue-600', 'bg-blue-50', 'border-blue-200');
        listViewBtn.classList.remove('text-gray-600', 'border-gray-300');
        gridViewBtn.classList.remove('text-blue-600', 'bg-blue-50', 'border-blue-200');
        gridViewBtn.classList.add('text-gray-600', 'border-gray-300');
    }
}

// Close sidebar when clicking outside (mobile)
document.addEventListener('click', function(event) {
    const sidebar = document.getElementById('sidebar');
    const toggleBtn = event.target.closest('button[onclick*="toggleSidebar"]');
    
    if (sidebar && !sidebar.contains(event.target) && !toggleBtn && window.innerWidth < 768) {
        if (!sidebar.classList.contains('sidebar-hidden')) {
            sidebar.classList.add('sidebar-hidden');
        }
    }
});

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    console.log('Student common script loaded');
});
