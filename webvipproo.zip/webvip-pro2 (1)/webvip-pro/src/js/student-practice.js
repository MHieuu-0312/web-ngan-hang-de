
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('sidebarOverlay');
            
            sidebar.classList.toggle('sidebar-hidden');
            overlay.classList.toggle('hidden');
        }

        function startStudyMode(mode) {
            switch(mode) {
                case 'flashcards':
                    alert('Bắt đầu học với flashcards! Đang chuyển hướng...');
                    // In real app, redirect to flashcards page
                    break;
                case 'practice':
                    alert('Bắt đầu luyện tập! Chọn chủ đề bạn muốn luyện...');
                    // In real app, show topic selection
                    break;
                case 'review':
                    alert('Ôn tập các câu đã làm sai! Đang tải...');
                    // In real app, load incorrect questions
                    break;
                case 'challenge':
                    alert('Bắt đầu thử thách hàng ngày! Sẵn sàng chưa?');
                    // In real app, start daily challenge
                    break;
            }
            
            // Show achievement notification
            setTimeout(() => {
                showAchievementNotification('Bắt đầu học tập!', 'Bạn nhận được 10 XP');
            }, 1000);
        }

        function continuePractice(subject) {
            const subjectNames = {
                'math': 'Toán học',
                'biology': 'Sinh học', 
                'literature': 'Ngữ văn'
            };
            
            alert(`Tiếp tục học ${subjectNames[subject]}! Đang tải bài tập tiếp theo...`);
            // In real app, load next lesson/exercise
            
            setTimeout(() => {
                showAchievementNotification('Tiếp tục học tập!', 'Bạn nhận được 5 XP');
            }, 500);
        }

        function flipCard(card) {
            card.classList.toggle('flipped');
        }

        function viewAllFlashcards() {
            alert('Đang mở thư viện flashcards...');
            // In real app, navigate to flashcards library
        }

        function showAchievementNotification(title, message) {
            const notification = document.getElementById('achievementNotification');
            notification.querySelector('p:first-child').textContent = title;
            notification.querySelector('p:last-child').textContent = message;
            
            notification.classList.add('show');
            
            setTimeout(() => {
                notification.classList.remove('show');
            }, 3000);
        }

        // Auto-flip flashcards for demo
        document.addEventListener('DOMContentLoaded', function() {
            const flashcards = document.querySelectorAll('.flashcard');
            flashcards.forEach((card, index) => {
                setTimeout(() => {
                    card.addEventListener('mouseenter', () => {
                        if (!card.classList.contains('flipped')) {
                            card.classList.add('flipped');
                        }
                    });
                    
                    card.addEventListener('mouseleave', () => {
                        if (card.classList.contains('flipped')) {
                            setTimeout(() => {
                                card.classList.remove('flipped');
                            }, 1000);
                        }
                    });
                }, index * 200);
            });
        });

        // Close sidebar when clicking outside on mobile
        window.addEventListener('resize', function() {
            if (window.innerWidth >= 768) {
                document.getElementById('sidebar').classList.remove('sidebar-hidden');
                document.getElementById('sidebarOverlay').classList.add('hidden');
            }
        });

        // Initialize animations
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(() => {
                document.querySelectorAll('.fade-in').forEach((el, index) => {
                    setTimeout(() => {
                        el.style.opacity = '1';
                        el.style.transform = 'translateY(0)';
                    }, index * 100);
                });
            }, 100);
        });

        // Simulate daily goal progress
        setInterval(() => {
            const goalElement = document.querySelector('.daily-goal h3');
            let currentGoal = parseInt(goalElement.textContent);
            if (currentGoal < 100) {
                currentGoal += Math.floor(Math.random() * 3) + 1;
                goalElement.textContent = Math.min(currentGoal, 100) + '%';
                
                if (currentGoal >= 100) {
                    setTimeout(() => {
                        showAchievementNotification('Mục tiêu hoàn thành!', 'Bạn đã đạt mục tiêu học tập hôm nay +200 XP');
                    }, 500);
                }
            }
        }, 10000)