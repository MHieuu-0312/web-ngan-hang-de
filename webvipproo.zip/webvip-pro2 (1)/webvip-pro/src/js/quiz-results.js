/* === NỘI DUNG MỚI THAY THẾ CHO: js/quiz-results.js === */
/* Mã này được viết để khớp với các ID trong quiz-results.html */

// BIẾN TOÀN CỤC ĐỂ GIỮ KẾT QUẢ ĐỘNG
let dynamicResults = {};

// KHỞI ĐỘNG KHI TRANG TẢI XONG
document.addEventListener('DOMContentLoaded', function() {
    // 1. Lấy dữ liệu từ sessionStorage
    const resultsDataString = sessionStorage.getItem('quizResultData');
    
    if (!resultsDataString) {
        // Nếu không có dữ liệu (ví dụ: người dùng vào thẳng trang này)
        alert("Không tìm thấy dữ liệu kết quả. Đang quay về trang chủ.");
        window.location.href = 'student-dashboard.html';
        return;
    }

    // 2. Chuyển đổi dữ liệu từ string về object
    dynamicResults = JSON.parse(resultsDataString);
    console.log("Dữ liệu kết quả đã nhận (ĐỘNG):", dynamicResults);

    // 3. Điền dữ liệu động vào trang
    populateResults(dynamicResults);

    // 4. (Quan trọng) Xóa dữ liệu cũ
    // Để tránh người dùng F5 và thấy lại kết quả cũ
    sessionStorage.removeItem('quizResultData');
});

// HÀM CHÍNH ĐỂ ĐIỀN DỮ LIỆU
function populateResults(results) {
    // 1. Header
    // Sửa tiêu đề H1 thành tên môn thi động
    document.querySelector('header h1').textContent = `Kết quả: ${results.subjectName}`;
    const today = new Date();
    // Điền thời gian (ID: completionTime)
    document.getElementById('completionTime').textContent = `Hoàn thành vào ${today.getDate()}/${today.getMonth() + 1}/${today.getFullYear()}`;

    // 2. Thẻ điểm chính
    const score = parseFloat(results.score);
    // Điền điểm (ID: finalScore)
    document.getElementById('finalScore').textContent = score.toFixed(1);
    
    // Cập nhật vòng tròn điểm (ID: scoreCircle)
    const circle = document.getElementById('scoreCircle');
    const radius = circle.r.baseVal.value;
    const circumference = radius * 2 * Math.PI;
    const offset = circumference - (score / 10) * circumference;
    // Cập nhật CSS của vòng tròn (từ file quiz-results.css)
    circle.style.strokeDashoffset = offset;

    // Cập nhật thanh hiệu suất (ID: performanceIndicator)
    const indicator = document.getElementById('performanceIndicator');
    indicator.style.width = `${score * 10}%`;
    
    // Cập nhật lời chúc (ID: performanceLevel, congratsMessage)
    const perfLevelEl = document.getElementById('performanceLevel');
    const congratsMsgEl = document.getElementById('congratsMessage');
    if (score >= 8.0) {
        perfLevelEl.innerHTML = `<i class="fas fa-star mr-2"></i> Xuất sắc`;
        congratsMsgEl.textContent = 'Chúc mừng! Bạn đã hoàn thành bài kiểm tra';
        circle.style.stroke = '#16a34a'; // Green
        indicator.style.backgroundColor = '#16a34a';
    } else if (score >= 6.5) {
        perfLevelEl.innerHTML = `<i class="fas fa-thumbs-up mr-2"></i> Giỏi`;
        congratsMsgEl.textContent = 'Làm tốt lắm!';
        circle.style.stroke = '#2563eb'; // Blue
        indicator.style.backgroundColor = '#2563eb';
    } else if (score >= 5.0) {
        perfLevelEl.innerHTML = `<i class="fas fa-check mr-2"></i> Khá`;
        congratsMsgEl.textContent = 'Bạn đã đạt!';
        circle.style.stroke = '#f59e0b'; // Yellow
        indicator.style.backgroundColor = '#f59e0b';
    } else {
        perfLevelEl.innerHTML = `<i class="fas fa-redo mr-2"></i> Cần cải thiện`;
        congratsMsgEl.textContent = 'Hãy cố gắng hơn vào lần sau!';
        circle.style.stroke = '#dc2626'; // Red
        indicator.style.backgroundColor = '#dc2626';
    }

    // 3. Các thẻ thống kê (ID: correctAnswers, incorrectAnswers, ...)
    document.getElementById('correctAnswers').textContent = results.correctCount;
    document.getElementById('incorrectAnswers').textContent = results.incorrectCount;
    document.getElementById('unansweredQuestions').textContent = results.unansweredCount;
    
    // Chuyển đổi giây sang Phút:Giây (ID: timeSpent)
    const minutes = Math.floor(results.timeSpent / 60);
    const seconds = results.timeSpent % 60;
    document.getElementById('timeSpent').textContent = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;

    // 4. Biểu đồ (ID 'resultChart')
    initChart(results);

    // 5. Thành tích (ID: achievementsList)
    document.getElementById('achievementsList').innerHTML = `
        <div class="achievement-badge"><i class="fas fa-brain mr-2"></i> Chuyên gia ${results.subjectName}</div>
        <div class="achievement-badge"><i class="fas fa-bolt mr-2"></i> Tốc độ</div>
    `;

    // 6. Xem lại câu hỏi (ID: questionsReview)
    populateReview(results);
}

// Vẽ biểu đồ
function initChart(results) {
    const ctx = document.getElementById('resultChart'); // Khớp với ID 'resultChart' của bạn
    if (!ctx) return;

    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Đúng', 'Sai', 'Bỏ qua'],
            datasets: [{
                data: [results.correctCount, results.incorrectCount, results.unansweredCount],
                backgroundColor: ['#16a34a', '#dc2626', '#f59e0b'],
                borderColor: '#ffffff',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '70%',
            plugins: {
                legend: { display: false },
            }
        }
    });
}

// Hiển thị xem lại câu hỏi
function populateReview(results) {
    const reviewContainer = document.getElementById('questionsReview');
    reviewContainer.innerHTML = ''; // Xóa nội dung tĩnh
    const optionLetters = ['A', 'B', 'C', 'D'];

    results.questions.forEach((question, index) => {
        const userAnswerIndex = results.userAnswers[index];
        const correctAnswerIndex = Number(question.correctAnswer);
        const isCorrect = (userAnswerIndex !== null && userAnswerIndex === correctAnswerIndex);

        let cardClass = isCorrect ? 'bg-green-50 border-green-300' : 'bg-red-50 border-red-300';
        let titleClass = isCorrect ? 'text-green-800' : 'text-red-800';
        let statusIcon = isCorrect ? 
            `<i class="fas fa-check-circle text-green-600 ml-2"></i>` : 
            `<i class="fas fa-times-circle text-red-600 ml-2"></i>`;

        if (userAnswerIndex === null) {
            cardClass = 'bg-yellow-50 border-yellow-300';
            titleClass = 'text-yellow-800';
            statusIcon = `<i class="fas fa-question-circle text-yellow-600 ml-2"></i>`;
        }

        const questionCard = document.createElement('div');
        // 'card' là class từ file css của bạn, chúng ta thêm nó vào
        questionCard.className = `question-review-card card ${cardClass} p-6`;
        
        let optionsHtml = '';
        question.options.forEach((option, i) => {
            let optionClass = 'flex items-center p-3 rounded-lg border border-gray-300';
            let optionIcon = '';
            if (i === correctAnswerIndex) {
                // Đáp án đúng
                optionClass = 'flex items-center p-3 rounded-lg border-2 border-green-500 bg-green-100';
                optionIcon = `<i class="fas fa-check text-green-600 ml-auto"></i>`;
            } else if (i === userAnswerIndex && !isCorrect) {
                // Đáp án sai user chọn
                optionClass = 'flex items-center p-3 rounded-lg border-2 border-red-500 bg-red-100';
                optionIcon = `<i class="fas fa-times text-red-600 ml-auto"></i>`;
            }

            optionsHtml += `
                <div class="${optionClass}">
                    <span class="font-medium mr-2">${optionLetters[i]}.</span>
                    <span>${option}</span>
                    ${optionIcon}
                </div>
            `;
        });

        questionCard.innerHTML = `
            <h4 class="text-lg font-semibold ${titleClass} mb-4">
                Câu ${index + 1}:
                ${statusIcon}
            </h4>
            <div class="text-base text-gray-800 mb-4">${question.text}</div>
            <div class="space-y-3">${optionsHtml}</div>
            ${question.explanation ? `
            <div class="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                <p class="font-semibold text-blue-700">Giải thích:</p>
                <p class="text-gray-700">${question.explanation}</p>
            </div>` : ''}
        `;
        reviewContainer.appendChild(questionCard);
    });
}

// --- CÁC HÀM TỪ HTML CỦA BẠN (Giữ nguyên) ---
// Các hàm này được gọi bằng onclick, nên chúng ta giữ lại
function printResults() {
    window.print();
}

function showAllQuestions() {
    document.querySelectorAll('.question-review-card').forEach(card => {
        card.style.display = 'block';
    });
}

function showIncorrectOnly() {
    document.querySelectorAll('.question-review-card').forEach(card => {
        if (card.classList.contains('bg-green-50')) {
            card.style.display = 'none';
        } else {
            card.style.display = 'block';
        }
    });
}

function retakeQuiz() {
    const subjectId = dynamicResults.subjectId; // Lấy subjectId từ dữ liệu động
    if (subjectId) {
        window.location.href = `quiz-taking.html?subject=${subjectId}`;
    } else {
        window.location.href = 'student-dashboard.html';
    }
}

function shareResults() {
    alert("Chức năng chia sẻ đang được phát triển!");
}