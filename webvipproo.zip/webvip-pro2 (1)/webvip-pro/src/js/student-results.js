// student-results.js - JavaScript cho trang kết quả học tập

function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    
    sidebar.classList.toggle('sidebar-hidden');
    overlay.classList.toggle('hidden');
}

function filterResults(category) {
    // Update active tab
    document.querySelectorAll('.filter-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    event.target.classList.add('active');

    // Filter results
    const resultItems = document.querySelectorAll('.result-item');
    resultItems.forEach(item => {
        if (category === 'all' || item.dataset.category === category) {
            item.style.display = 'table-row';
        } else {
            item.style.display = 'none';
        }
    });
}

function startPractice(topic) {
    alert(`Bắt đầu luyện tập chủ đề ${topic}! Đang chuyển hướng...`);
    // In real app, redirect to practice page with specific topic
}

// Initialize performance chart
function initPerformanceChart() {
    const ctx = document.getElementById('performanceChart').getContext('2d');
    const performanceChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['T1', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'T8', 'T9', 'T10', 'T11', 'T12'],
            datasets: [{
                label: 'Điểm trung bình',
                data: [7.2, 7.5, 7.8, 8.1, 8.0, 8.3, 8.5, 8.2, 8.4, 8.7, 8.5, 8.5],
                borderColor: '#2563eb',
                backgroundColor: 'rgba(37, 99, 235, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: false,
                    min: 6,
                    max: 10,
                    title: {
                        display: true,
                        text: 'Điểm số'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Tháng'
                    }
                }
            },
            elements: {
                point: {
                    radius: 5,
                    backgroundColor: '#2563eb',
                    borderColor: '#ffffff',
                    borderWidth: 2
                }
            }
        }
    });
}

// Close sidebar when clicking outside on mobile
window.addEventListener('resize', function() {
    if (window.innerWidth >= 768) {
        document.getElementById('sidebar').classList.remove('sidebar-hidden');
        document.getElementById('sidebarOverlay').classList.add('hidden');
    }
});

// Initialize animations
function initFadeInAnimations() {
    setTimeout(() => {
        document.querySelectorAll('.fade-in').forEach((el, index) => {
            setTimeout(() => {
                el.style.opacity = '1';
                el.style.transform = 'translateY(0)';
            }, index * 100);
        });
    }, 100);
}

// Animate progress rings
function animateProgressRings() {
    const rings = document.querySelectorAll('.progress-ring__circle');
    rings.forEach((ring, index) => {
        setTimeout(() => {
            const progress = [78, 65, 52][index] / 100;
            const offset = 251 - (progress * 251);
            ring.style.strokeDashoffset = offset;
        }, (index + 1) * 500);
    });
}

// Initialize all functions when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initPerformanceChart();
    initFadeInAnimations();
    animateProgressRings();
});
