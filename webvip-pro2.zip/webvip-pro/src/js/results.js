/* ========================================
   RESULTS PAGE JAVASCRIPT
   Hiển thị và phân tích kết quả
   ======================================== */

// Filter results
function filterResults(filter) {
    const resultItems = document.querySelectorAll('.result-item');
    const filterBtns = document.querySelectorAll('.filter-btn');
    
    // Update active filter button
    filterBtns.forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.filter === filter) {
            btn.classList.add('active');
        }
    });
    
    // Filter result items
    resultItems.forEach(item => {
        if (filter === 'all') {
            item.style.display = '';
        } else if (filter === 'passed') {
            const score = parseFloat(item.dataset.score);
            item.style.display = score >= 5 ? '' : 'none';
        } else if (filter === 'failed') {
            const score = parseFloat(item.dataset.score);
            item.style.display = score < 5 ? '' : 'none';
        } else {
            item.style.display = item.dataset.subject === filter ? '' : 'none';
        }
    });
}

// Sort results
function sortResults(sortBy) {
    const container = document.getElementById('resultsContainer');
    if (!container) return;
    
    const items = Array.from(container.querySelectorAll('.result-item'));
    
    items.sort((a, b) => {
        if (sortBy === 'date-desc') {
            return new Date(b.dataset.date) - new Date(a.dataset.date);
        } else if (sortBy === 'date-asc') {
            return new Date(a.dataset.date) - new Date(b.dataset.date);
        } else if (sortBy === 'score-desc') {
            return parseFloat(b.dataset.score) - parseFloat(a.dataset.score);
        } else if (sortBy === 'score-asc') {
            return parseFloat(a.dataset.score) - parseFloat(b.dataset.score);
        }
        return 0;
    });
    
    // Re-append sorted items
    items.forEach(item => container.appendChild(item));
}

// View result details
function viewResultDetails(resultId) {
    window.location.href = `quiz-results.html?id=${resultId}`;
}

// Initialize charts for results analysis
function initResultsChart() {
    const ctx = document.getElementById('resultsChart');
    if (!ctx || typeof Chart === 'undefined') return;
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'],
            datasets: [{
                label: 'Điểm trung bình',
                data: [7.5, 8.0, 7.8, 8.5, 8.2, 8.7, 9.0],
                borderColor: '#2563eb',
                backgroundColor: 'rgba(37, 99, 235, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 10
                }
            }
        }
    });
}

function initSubjectComparisonChart() {
    const ctx = document.getElementById('subjectChart');
    if (!ctx || typeof Chart === 'undefined') return;
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Toán', 'Văn', 'Anh', 'Lý', 'Hóa', 'Sinh'],
            datasets: [{
                label: 'Điểm trung bình',
                data: [8.5, 7.8, 9.0, 8.2, 7.5, 8.8],
                backgroundColor: [
                    '#2563eb',
                    '#7c3aed',
                    '#16a34a',
                    '#f59e0b',
                    '#dc2626',
                    '#06b6d4'
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 10
                }
            }
        }
    });
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    // Initialize charts if on results page with charts
    if (typeof Chart !== 'undefined') {
        initResultsChart();
        initSubjectComparisonChart();
    }
    
    console.log('Results page initialized');
});
