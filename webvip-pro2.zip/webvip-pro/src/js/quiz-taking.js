// ====================================
// QUIZ TAKING FUNCTIONALITY
// ====================================

// Quiz State
let currentQuestion = 0;
let totalQuestions = 20;
let timeRemaining = 1800; // 30 minutes
let answers = new Array(totalQuestions).fill(null);
let sidebarCollapsed = false;
let timerInterval;

// Sample Questions Data
const questions = [
    {
        id: 1,
        text: "Giải phương trình sau: 2x + 5 = 13",
        options: ["x = 4", "x = 5", "x = 6", "x = 8"],
        correct: 0,
        points: 2
    },
    {
        id: 2,
        text: "Tìm giá trị của x trong phương trình: 3x - 7 = 14",
        options: ["x = 5", "x = 6", "x = 7", "x = 8"],
        correct: 2,
        points: 2
    },
    {
        id: 3,
        text: "Nghiệm của phương trình x² - 5x + 6 = 0 là:",
        options: ["x = 1, x = 6", "x = 2, x = 3", "x = -2, x = -3", "x = 1, x = -6"],
        correct: 1,
        points: 3
    }
];

// Generate sample questions
while (questions.length < totalQuestions) {
    const baseQuestion = questions[questions.length % 3];
    questions.push({
        ...baseQuestion,
        id: questions.length + 1,
        text: `Câu hỏi ${questions.length + 1}: ` + baseQuestion.text
    });
}

// ====================================
// INITIALIZATION
// ====================================

function initQuiz() {
    generateQuestionGrid();
    loadQuestion(0);
    startTimer();
    updateProgress();
}

function generateQuestionGrid() {
    const grid = document.getElementById('questionGrid');
    grid.innerHTML = '';
    
    for (let i = 0; i < totalQuestions; i++) {
        const item = document.createElement('div');
        item.className = `question-nav-item ${i === 0 ? 'current' : 'unanswered'}`;
        item.textContent = i + 1;
        item.onclick = () => goToQuestion(i);
        grid.appendChild(item);
    }
}

// ====================================
// QUESTION MANAGEMENT
// ====================================

function loadQuestion(index) {
    if (index < 0 || index >= totalQuestions) return;
    
    currentQuestion = index;
    const question = questions[index];
    
    // Update question content
    document.getElementById('currentQuestionNumber').textContent = index + 1;
    document.getElementById('questionText').textContent = question.text;
    
    // Update answer options
    const optionsContainer = document.getElementById('answerOptions');
    optionsContainer.innerHTML = '';
    
    question.options.forEach((option, i) => {
        const optionElement = document.createElement('div');
        optionElement.className = `answer-option border-2 border-gray-200 rounded-lg p-4 ${answers[index] === i ? 'selected' : ''}`;
        optionElement.onclick = () => selectAnswer(i);
        
        optionElement.innerHTML = `
            <div class="flex items-center">
                <span class="w-6 h-6 rounded-full border-2 border-gray-300 flex items-center justify-center mr-3 text-sm font-medium">
                    ${String.fromCharCode(65 + i)}
                </span>
                <span>${option}</span>
            </div>
        `;
        
        optionsContainer.appendChild(optionElement);
    });
    
    // Update navigation buttons
    document.getElementById('prevButton').disabled = index === 0;
    document.getElementById('nextButton').textContent = index === totalQuestions - 1 ? 'Hoàn thành' : 'Câu tiếp theo';
    
    // Update navigation grid
    updateNavigationGrid();
    updateProgress();
}

function selectAnswer(optionIndex) {
    answers[currentQuestion] = optionIndex;
    
    document.querySelectorAll('.answer-option').forEach((option, index) => {
        if (index === optionIndex) {
            option.classList.add('selected');
        } else {
            option.classList.remove('selected');
        }
    });
    
    updateNavigationGrid();
    updateProgress();
}

function clearAnswer() {
    answers[currentQuestion] = null;
    document.querySelectorAll('.answer-option').forEach(option => {
        option.classList.remove('selected');
    });
    updateNavigationGrid();
    updateProgress();
}

// ====================================
// NAVIGATION
// ====================================

function nextQuestion() {
    if (currentQuestion < totalQuestions - 1) {
        loadQuestion(currentQuestion + 1);
    } else {
        showSubmitModal();
    }
}

function previousQuestion() {
    if (currentQuestion > 0) {
        loadQuestion(currentQuestion - 1);
    }
}

function goToQuestion(index) {
    loadQuestion(index);
}

function updateNavigationGrid() {
    document.querySelectorAll('.question-nav-item').forEach((item, index) => {
        item.className = 'question-nav-item';
        
        if (index === currentQuestion) {
            item.classList.add('current');
        } else if (answers[index] !== null) {
            item.classList.add('answered');
        } else {
            item.classList.add('unanswered');
        }
    });
}

// ====================================
// PROGRESS TRACKING
// ====================================

function updateProgress() {
    const answeredCount = answers.filter(answer => answer !== null).length;
    const remainingCount = totalQuestions - answeredCount;
    const progressPercent = (answeredCount / totalQuestions) * 100;
    
    document.getElementById('answeredCount').textContent = answeredCount;
    document.getElementById('remainingCount').textContent = remainingCount;
    document.getElementById('progressText').textContent = `${answeredCount}/${totalQuestions}`;
    document.getElementById('progressBar').style.width = `${progressPercent}%`;
}

// ====================================
// TIMER
// ====================================

function startTimer() {
    timerInterval = setInterval(updateTimer, 1000);
}

function updateTimer() {
    timeRemaining--;
    
    const minutes = Math.floor(timeRemaining / 60);
    const seconds = timeRemaining % 60;
    const timeDisplay = `${minutes}:${seconds.toString().padStart(2, '0')}`;
    
    document.getElementById('timeDisplay').textContent = timeDisplay;
    
    // Update timer circle
    const totalTime = 1800;
    const progress = (totalTime - timeRemaining) / totalTime;
    const offset = 283 - (progress * 283);
    document.getElementById('timerCircle').style.strokeDashoffset = offset;
    
    // Change color when time is running low
    const timerCircle = document.getElementById('timerCircle');
    const timeDisplayElement = document.getElementById('timeDisplay');
    
    if (timeRemaining <= 300) { // 5 minutes
        timerCircle.style.stroke = '#ef4444';
        timeDisplayElement.classList.add('time-warning');
        
        if (timeRemaining === 300) {
            showTimeWarning();
        }
    } else if (timeRemaining <= 600) { // 10 minutes
        timerCircle.style.stroke = '#f59e0b';
    }
    
    if (timeRemaining <= 0) {
        clearInterval(timerInterval);
        autoSubmitQuiz();
    }
}

// ====================================
// MODALS
// ====================================

function showSubmitModal() {
    const answeredCount = answers.filter(answer => answer !== null).length;
    const minutes = Math.floor(timeRemaining / 60);
    const seconds = timeRemaining % 60;
    const timeDisplay = `${minutes}:${seconds.toString().padStart(2, '0')}`;
    
    document.getElementById('modalAnsweredCount').textContent = `${answeredCount}/${totalQuestions}`;
    document.getElementById('modalTimeRemaining').textContent = timeDisplay;
    document.getElementById('submitModal').style.display = 'block';
}

function closeSubmitModal() {
    document.getElementById('submitModal').style.display = 'none';
}

function showTimeWarning() {
    document.getElementById('timeWarningModal').style.display = 'block';
}

function closeTimeWarning() {
    document.getElementById('timeWarningModal').style.display = 'none';
}

// ====================================
// SUBMISSION
// ====================================

function submitQuiz() {
    clearInterval(timerInterval);
    
    const correctAnswers = answers.filter((answer, index) => {
        return answer === questions[index].correct;
    }).length;
    
    const results = {
        totalQuestions: totalQuestions,
        correctAnswers: correctAnswers,
        score: (correctAnswers / totalQuestions * 10).toFixed(1),
        timeSpent: 1800 - timeRemaining,
        answers: answers,
        questions: questions
    };
    
    localStorage.setItem('quizResults', JSON.stringify(results));
    window.location.href = 'quiz-results.html';
}

function autoSubmitQuiz() {
    alert('Hết thời gian! Bài kiểm tra sẽ được tự động nộp.');
    submitQuiz();
}

// ====================================
// SIDEBAR
// ====================================

function toggleSidebar() {
    const sidebar = document.getElementById('questionSidebar');
    const icon = document.getElementById('sidebarIcon');
    
    sidebarCollapsed = !sidebarCollapsed;
    
    if (sidebarCollapsed) {
        sidebar.classList.remove('sidebar-expanded');
        sidebar.classList.add('sidebar-collapsed');
        icon.className = 'fas fa-chevron-right';
    } else {
        sidebar.classList.remove('sidebar-collapsed');
        sidebar.classList.add('sidebar-expanded');
        icon.className = 'fas fa-chevron-left';
    }
}

// ====================================
// EVENT LISTENERS
// ====================================

// Prevent accidental page close
window.addEventListener('beforeunload', function(e) {
    if (timeRemaining > 0) {
        e.preventDefault();
        e.returnValue = 'Bạn có chắc chắn muốn rời khỏi trang? Bài làm sẽ không được lưu.';
    }
});

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    switch(e.key) {
        case 'ArrowLeft':
            if (currentQuestion > 0) previousQuestion();
            break;
        case 'ArrowRight':
            if (currentQuestion < totalQuestions - 1) nextQuestion();
            break;
        case '1':
        case '2':
        case '3':
        case '4':
            if (!e.ctrlKey && !e.altKey) {
                const optionIndex = parseInt(e.key) - 1;
                if (optionIndex < questions[currentQuestion].options.length) {
                    selectAnswer(optionIndex);
                }
            }
            break;
        case 'Delete':
        case 'Backspace':
            if (e.ctrlKey) {
                clearAnswer();
            }
            break;
    }
});

// Initialize on page load
document.addEventListener('DOMContentLoaded', initQuiz);

// Auto-save progress every 30 seconds
setInterval(() => {
    localStorage.setItem('quizProgress', JSON.stringify({
        currentQuestion: currentQuestion,
        answers: answers,
        timeRemaining: timeRemaining
    }));
}, 30000);
