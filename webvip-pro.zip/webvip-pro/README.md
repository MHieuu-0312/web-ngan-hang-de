
  # Homepage Design for Scribble

  This is a code bundle for Homepage Design for Scribble. The original project is available at https://www.figma.com/design/XPjqt57mSEK35yvgKCTyBF/Homepage-Design-for-Scribble.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  