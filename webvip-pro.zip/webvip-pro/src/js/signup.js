/* ========================================
   SIGNUP PAGE JAVASCRIPT
   ======================================== */

let currentStep = 1;
let selectedRole = '';

// Select user role (student/teacher)
function selectRole(role) {
    selectedRole = role;
    document.getElementById('selectedRole').value = role;
    
    // Update UI
    document.getElementById('teacherCard').classList.remove('selected');
    document.getElementById('studentCard').classList.remove('selected');
    document.getElementById(role + 'Card').classList.add('selected');
    
    // Enable next button
    document.getElementById('step1Btn').disabled = false;
    document.getElementById('roleError').style.display = 'none';
    
    // Update school field label
    if (role === 'teacher') {
        document.getElementById('schoolLabel').textContent = 'Trường/Tổ chức';
        document.getElementById('school').placeholder = 'Nhập tên trường hoặc tổ chức';
    } else {
        document.getElementById('schoolLabel').textContent = 'Trường học';
        document.getElementById('school').placeholder = 'Nhập tên trường học';
    }
}

// Update step indicator visual state
function updateStepIndicator() {
    for (let i = 1; i <= 3; i++) {
        const step = document.getElementById(`step${i}`);
        const line = document.getElementById(`line${i}`);
        
        if (i < currentStep) {
            step.className = 'step completed';
            if (line) line.className = 'step-line completed';
        } else if (i === currentStep) {
            step.className = 'step current';
        } else {
            step.className = 'step pending';
        }
    }
}

// Show specific form step
function showStep(step) {
    document.querySelectorAll('.form-step').forEach(el => el.classList.remove('active'));
    document.getElementById(`formStep${step}`).classList.add('active');
}

// Move to next step
function nextStep() {
    if (validateCurrentStep()) {
        currentStep++;
        updateStepIndicator();
        showStep(currentStep);
    }
}

// Move to previous step
function prevStep() {
    currentStep--;
    updateStepIndicator();
    showStep(currentStep);
}

// Validate current step data
function validateCurrentStep() {
    if (currentStep === 1) {
        if (!selectedRole) {
            document.getElementById('roleError').style.display = 'block';
            return false;
        }
        return true;
    } else if (currentStep === 2) {
        return validatePersonalInfo();
    }
    return true;
}

// Validate personal information (Step 2)
function validatePersonalInfo() {
    const name = document.getElementById('fullName').value;
    const email = document.getElementById('email').value;
    const phone = document.getElementById('phone').value;
    
    let isValid = true;
    
    // Reset errors
    document.querySelectorAll('.error-message').forEach(el => el.style.display = 'none');
    
    // Validate name
    if (!name.trim()) {
        document.getElementById('nameError').style.display = 'block';
        isValid = false;
    }
    
    // Validate email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        document.getElementById('emailError').style.display = 'block';
        isValid = false;
    }
    
    // Validate phone
    const phoneRegex = /^[\d\s\-\+\(\)]{10,}$/;
    if (!phoneRegex.test(phone)) {
        document.getElementById('phoneError').style.display = 'block';
        isValid = false;
    }
    
    return isValid;
}

// Validate final step (Step 3)
function validateFinalStep() {
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const terms = document.getElementById('terms').checked;
    
    let isValid = true;
    
    // Reset errors
    document.querySelectorAll('.error-message').forEach(el => el.style.display = 'none');
    
    // Validate password strength
    if (password.length < 8 || !/[a-zA-Z]/.test(password) || !/\d/.test(password)) {
        document.getElementById('passwordError').style.display = 'block';
        isValid = false;
    }
    
    // Validate password match
    if (password !== confirmPassword) {
        document.getElementById('confirmPasswordError').style.display = 'block';
        isValid = false;
    }
    
    // Validate terms acceptance
    if (!terms) {
        document.getElementById('termsError').style.display = 'block';
        isValid = false;
    }
    
    return isValid;
}

// Toggle password visibility
function togglePassword(fieldId) {
    const input = document.getElementById(fieldId);
    const icon = document.getElementById(fieldId + 'Icon');
    
    if (input.type === 'password') {
        input.type = 'text';
        icon.className = 'fas fa-eye-slash text-gray-400';
    } else {
        input.type = 'password';
        icon.className = 'fas fa-eye text-gray-400';
    }
}

// Check password strength
function checkPasswordStrength() {
    const password = document.getElementById('password').value;
    const strengthBar = document.getElementById('strengthBar');
    const strengthText = document.getElementById('strengthText');
    
    let strength = 0;
    
    // Check length
    if (password.length >= 8) strength++;
    if (password.length >= 12) strength++;
    
    // Check for lowercase and uppercase
    if (/[a-z]/.test(password) && /[A-Z]/.test(password)) strength++;
    
    // Check for numbers
    if (/\d/.test(password)) strength++;
    
    // Check for special characters
    if (/[^a-zA-Z\d]/.test(password)) strength++;
    
    // Update UI based on strength
    strengthBar.className = 'strength-bar';
    
    if (strength <= 1) {
        strengthBar.classList.add('strength-weak');
        strengthText.textContent = 'Yếu';
    } else if (strength === 2) {
        strengthBar.classList.add('strength-fair');
        strengthText.textContent = 'Trung bình';
    } else if (strength === 3 || strength === 4) {
        strengthBar.classList.add('strength-good');
        strengthText.textContent = 'Tốt';
    } else {
        strengthBar.classList.add('strength-strong');
        strengthText.textContent = 'Mạnh';
    }
}

// Initialize form when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    const signupForm = document.getElementById('signupForm');
    
    if (signupForm) {
        signupForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            if (validateFinalStep()) {
                // Show success message
                document.getElementById('successMessage').style.display = 'block';
                
                // Simulate account creation and redirect
                setTimeout(() => {
                    // Redirect based on role
                    window.location.href = 'student-dashboard.html';
                }, 2000);
            }
        });
    }
});
