/* === NỘI DUNG MỚI THAY THẾ CHO: js/signup.js === */
/* (Phiên bản 2-bước, đã sửa lỗi ID Step lần cuối) */

// Biến 'auth' và 'db' đã được tạo trong file .html
// const auth = firebase.auth();
// const db = firebase.firestore();

let currentStep = 1; // currentStep = 1 là formStep1, currentStep = 2 là formStep2

document.addEventListener('DOMContentLoaded', function() {
    // Hiển thị bước 1 ngay khi tải trang
    showStep(1);
    updateStepIndicator();

    const signupForm = document.getElementById('signupForm');

    // Thêm sự kiện 'submit' cho form (chỉ kích hoạt ở bước cuối)
    signupForm.addEventListener('submit', function(e) {
        e.preventDefault(); // Ngăn form tự động gửi

        // Chỉ chạy logic submit nếu đang ở bước cuối cùng
        if (currentStep === 2) {
            handleFormSubmit();
        }
    });
});

// Hàm chuyển sang bước tiếp theo (được gọi từ onclick="nextStep()")
function nextStep() {
    if (currentStep === 1) {
        // Kiểm tra dữ liệu ở bước 1
        if (validateStep1()) {
            currentStep = 2;
            showStep(2);
            updateStepIndicator();
        }
    }
}

// Hàm quay lại bước trước (được gọi từ onclick="prevStep()")
function prevStep() {
    if (currentStep === 2) {
        currentStep = 1;
        showStep(1);
        updateStepIndicator();
    }
}

// --- HÀM VALIDATE ---

// Hàm ẩn tất cả thông báo lỗi
function hideAllErrors() {
    document.querySelectorAll('.error-message').forEach(el => el.style.display = 'none');
}

// Hàm kiểm tra dữ liệu bước 1
function validateStep1() {
    hideAllErrors();
    let isValid = true;

    // Dùng ID 'fullName' từ HTML
    const fullName = document.getElementById('fullName').value;
    const email = document.getElementById('email').value;

    if (fullName.trim() === '') {
        document.getElementById('nameError').style.display = 'block';
        isValid = false;
    }

    // Kiểm tra email đơn giản
    if (email.trim() === '' || !email.includes('@')) {
        document.getElementById('emailError').style.display = 'block';
        isValid = false;
    }

    return isValid;
}

// Hàm kiểm tra dữ liệu bước 2 (trước khi submit)
function validateStep2() {
    hideAllErrors();
    let isValid = true;

    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const terms = document.getElementById('terms').checked;

    if (password.length < 6) { // Firebase yêu cầu tối thiểu 6 ký tự
        document.getElementById('passwordError').textContent = 'Mật khẩu phải có ít nhất 6 ký tự.';
        document.getElementById('passwordError').style.display = 'block';
        isValid = false;
    }
    if (password !== confirmPassword) {
        document.getElementById('confirmPasswordError').style.display = 'block';
        isValid = false;
    }
    if (!terms) {
        document.getElementById('termsError').style.display = 'block';
        isValid = false;
    }
    return isValid;
}

// --- HÀM HIỂN THỊ (ĐÃ SỬA LỖI ID STEP) ---

// Hàm ẩn/hiện các bước
function showStep(stepNumber) {
    // Ẩn tất cả các bước
    // SỬA LỖI ID: Dùng 'formStep1' và 'formStep2'
    document.getElementById('formStep1').classList.remove('active');
    document.getElementById('formStep2').classList.remove('active');

    if (stepNumber === 1) {
        // SỬA LỖI ID: Hiển thị 'formStep1'
        document.getElementById('formStep1').classList.add('active');
    } else if (stepNumber === 2) {
        // SỬA LỖI ID: Hiển thị 'formStep2'
        document.getElementById('formStep2').classList.add('active');
    }
}

// Hàm cập nhật thanh chỉ báo (step indicator)
function updateStepIndicator() {
    const step1 = document.getElementById('step1');
    const line1 = document.getElementById('line1');
    const step2 = document.getElementById('step2');

    if (currentStep === 1) {
        step1.className = 'step current';
        line1.className = 'step-line pending';
        step2.className = 'step pending';
    } else if (currentStep === 2) {
        step1.className = 'step completed';
        line1.className = 'step-line completed';
        step2.className = 'step current';
    }
}

// --- HÀM XỬ LÝ FIREBASE ---

// Hàm xử lý logic submit cuối cùng
function handleFormSubmit() {
    // Kiểm tra dữ liệu bước 2
    if (!validateStep2()) {
        return; // Dừng lại nếu dữ liệu sai
    }

    // Lấy TẤT CẢ dữ liệu từ 2 bước
    const fullName = document.getElementById('fullName').value; // Từ bước 1
    const email = document.getElementById('email').value;       // Từ bước 1
    const password = document.getElementById('password').value; // Từ bước 2

    // Lấy các phần tử UI
    const submitButton = document.querySelector('#formStep2 button[type="submit"]'); // Tìm nút submit trong bước 2
    const successMessage = document.getElementById('successMessage');

    submitButton.disabled = true;
    submitButton.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Đang xử lý...';

    // === BƯỚC 1: TẠO TÀI KHOẢN TRÊN FIREBASE AUTH ===
    auth.createUserWithEmailAndPassword(email, password)
        .then((userCredential) => {
            const user = userCredential.user;
            console.log('Đã tạo tài khoản Auth thành công:', user.uid);

            // === BƯỚC 2: LƯU THÔNG TIN BỔ SUNG VÀO FIRESTORE ===
            return db.collection('users').doc(user.uid).set({
                name: fullName,
                email: email,
                role: 'student',
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            });
        })
        .then(() => {
            // Cả 2 bước đã thành công!
            console.log('Đã lưu thông tin user vào Firestore.');

            // Ẩn form và hiển thị thông báo thành công
            document.getElementById('signupForm').style.display = 'none';
            if (successMessage) {
                 // Sửa lại class để Tailwind hiển thị
                 successMessage.className = 'block p-4 mb-4 text-sm text-green-700 bg-green-100 rounded-lg text-center mt-4';
                 successMessage.textContent = 'Tài khoản đã được tạo thành công! Đang chuyển hướng...';
            }

            // Chờ 2 giây rồi chuyển hướng đến trang ĐĂNG NHẬP
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 2000);
        })
        .catch((error) => {
            // Xảy ra lỗi
            console.error('Lỗi đăng ký:', error);

            // Kích hoạt lại nút bấm
            submitButton.disabled = false;
            submitButton.innerHTML = '<i class="fas fa-user-plus mr-2"></i> Tạo tài khoản';

            if (error.code === 'auth/email-already-in-use') {
                alert('Lỗi: Email này đã được sử dụng.');
                // Quay lại bước 1 để user sửa email
                prevStep();
            } else {
                alert('Đã xảy ra lỗi: ' + error.message);
            }
        });
}


// --- CÁC HÀM TIỆN ÍCH (Từ HTML của bạn) ---

function togglePassword(fieldId) {
    const input = document.getElementById(fieldId);
    const icon = document.getElementById(fieldId + 'Icon'); // Giả định ID icon là fieldId + 'Icon'
    if (!input || !icon) return; // Kiểm tra nếu phần tử không tồn tại

    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

function checkPasswordStrength() {
    const password = document.getElementById('password').value;
    const strengthBar = document.getElementById('strengthBar');
    const strengthText = document.getElementById('strengthText');
    if (!strengthBar || !strengthText) return; // Kiểm tra nếu phần tử không tồn tại

    let strength = 0;
    if (password.length >= 6) strength++; // Firebase min 6
    if (password.match(/[a-z]/)) strength++;
    if (password.match(/[A-Z]/)) strength++;
    if (password.match(/[0-9]/)) strength++;
    if (password.match(/[^a-zA-Z0-9]/)) strength++;

    strengthBar.className = 'strength-bar'; // Reset class

    switch (strength) {
        case 0:
        case 1:
            strengthBar.classList.add('strength-weak');
            strengthText.textContent = 'Yếu';
            break;
        case 2:
            strengthBar.classList.add('strength-fair');
            strengthText.textContent = 'Trung bình';
            break;
        case 3:
        case 4:
            strengthBar.classList.add('strength-good');
            strengthText.textContent = 'Tốt';
            break;
        case 5:
            strengthBar.classList.add('strength-strong');
            strengthText.textContent = 'Mạnh';
            break;
    }
}