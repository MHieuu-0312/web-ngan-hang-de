/**
 * DASHBOARD JAVASCRIPT
 * Student Dashboard functionality
 */

// ==========================================
// SIDEBAR TOGGLE (Mobile)
// ==========================================
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    if (sidebar) {
        sidebar.classList.toggle('sidebar-hidden');
    }
}

// ==========================================
// SECTION SWITCHING
// ==========================================
function showSection(sectionName) {
    // Hide all sections
    const sections = document.querySelectorAll('[id$="Section"]');
    sections.forEach(section => {
        section.classList.add('hidden');
    });
    
    // Show selected section
    const targetSection = document.getElementById(sectionName + 'Section');
    if (targetSection) {
        targetSection.classList.remove('hidden');
    }
    
    // Update navigation active state
    const navLinks = document.querySelectorAll('aside nav a');
    navLinks.forEach(link => {
        link.classList.remove('text-blue-600', 'bg-blue-50');
        link.classList.add('text-gray-700');
    });
    
    // Add active class to clicked link
    event.target.classList.add('text-blue-600', 'bg-blue-50');
    event.target.classList.remove('text-gray-700');
}

// ==========================================
// CHARTS INITIALIZATION
// ==========================================
function initProgressChart() {
    const ctx = document.getElementById('progressChart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'],
            datasets: [{
                label: 'Điểm trung bình',
                data: [7.5, 8.0, 7.8, 8.5, 8.2, 8.7, 9.0],
                borderColor: '#2563eb',
                backgroundColor: 'rgba(37, 99, 235, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 10
                }
            }
        }
    });
}

function initSubjectChart() {
    const ctx = document.getElementById('subjectChart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Toán', 'Văn', 'Anh', 'Lý', 'Hóa', 'Sinh'],
            datasets: [{
                label: 'Điểm số',
                data: [8.5, 7.8, 9.0, 8.2, 7.5, 8.8],
                backgroundColor: [
                    '#2563eb',
                    '#7c3aed',
                    '#16a34a',
                    '#f59e0b',
                    '#dc2626',
                    '#06b6d4'
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 10
                }
            }
        }
    });
}

function initPerformanceChart() {
    const ctx = document.getElementById('performanceChart');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Hoàn thành', 'Chưa hoàn thành'],
            datasets: [{
                data: [75, 25],
                backgroundColor: ['#2563eb', '#e5e7eb']
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

// ==========================================
// INITIALIZE DASHBOARD
// ==========================================
document.addEventListener('DOMContentLoaded', function() {
    // Initialize charts if Chart.js is available
    if (typeof Chart !== 'undefined') {
        initProgressChart();
        initSubjectChart();
        initPerformanceChart();
    }
    
    console.log('Dashboard initialized!');
});
