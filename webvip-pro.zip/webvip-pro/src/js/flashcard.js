
        // Mảng dữ liệu flashcard ví dụ (bạn sẽ thay thế bằng dữ liệu thật)
        const flashcardsData = [
            {
                front: { title: "Phương trình bậc hai", text: "Công thức nghiệm của phương trình $ax^2 + bx + c = 0$ là gì?" },
                back: { title: "Đáp án", text: "$x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}$", note: "(Với $\\Delta = b^2 - 4ac \\ge 0$)" }
            },
            {
                front: { title: "Tế bào", text: "Bào quan nào có chức năng tổng hợp protein?" },
                back: { title: "Đáp án", text: "Ribosome" }
            },
            {
                front: { title: "Văn học", text: "Tác giả của tác phẩm \"Số đỏ\" là ai?" },
                back: { title: "Đáp án", text: "Vũ Trọng Phụng" }
            },
            {
                front: { title: "Vật lý", text: "Công thức tính động năng là gì?" },
                back: { title: "Đáp án", text: "$E_k = \\frac{1}{2}mv^2$", note:"(m: khối lượng, v: vận tốc)"}
            },
            {
                front: { title: "Hóa học", text: "Nguyên tố phổ biến nhất trong vỏ Trái Đất là gì?" },
                back: { title: "Đáp án", text: "Oxy (O)" }
            }
            // Thêm các thẻ khác vào đây...
        ];

        let currentCardIndex = 0;
        const flashcardElement = document.querySelector('.flashcard');
        const frontFace = flashcardElement.querySelector('.flashcard-front > div');
        const backFace = flashcardElement.querySelector('.flashcard-back > div');
        const currentCardNumberEl = document.getElementById('currentCardNumber');
        const totalCardNumberEl = document.getElementById('totalCardNumber');
        const prevButton = document.getElementById('prevButton');
        const nextButton = document.getElementById('nextButton');

        // Hàm lật thẻ
        function flipCard(card) {
            card.classList.toggle('is-flipped');
        }

        // Hàm tải nội dung thẻ
        function loadCard(index) {
            if (index < 0 || index >= flashcardsData.length) return; // Kiểm tra giới hạn

            const cardData = flashcardsData[index];

            // Cập nhật mặt trước
            frontFace.innerHTML = `
                <h4 class="text-xl md:text-2xl font-bold mb-4 text-blue-600">${cardData.front.title}</h4>
                <p class="text-base md:text-lg text-gray-700">${cardData.front.text}</p>
            `;

            // Cập nhật mặt sau
            backFace.innerHTML = `
                <h4 class="text-xl md:text-2xl font-bold mb-4">${cardData.back.title}</h4>
                <p class="text-base md:text-lg">${cardData.back.text}</p>
                ${cardData.back.note ? `<p class="text-sm mt-4 opacity-80">${cardData.back.note}</p>` : ''}
            `;

             // Reset trạng thái lật về mặt trước
            if (flashcardElement.classList.contains('is-flipped')) {
                flashcardElement.classList.remove('is-flipped');
            }

            // Cập nhật chỉ số thẻ
            currentCardIndex = index;
            currentCardNumberEl.textContent = currentCardIndex + 1;

             // Cập nhật trạng thái nút Prev/Next
            prevButton.disabled = (currentCardIndex === 0);
            nextButton.disabled = (currentCardIndex === flashcardsData.length - 1);

            // Render lại MathJax nếu bạn dùng công thức toán
            if (window.MathJax) {
                 MathJax.typesetPromise();
             }
        }

        // Hàm chuyển thẻ tiếp theo
        function nextCard() {
            loadCard(currentCardIndex + 1);
        }

        // Hàm quay lại thẻ trước
        function prevCard() {
             loadCard(currentCardIndex - 1);
        }

        // Khởi tạo thẻ đầu tiên khi tải trang
        document.addEventListener('DOMContentLoaded', () => {
            totalCardNumberEl.textContent = flashcardsData.length;
            loadCard(0); // Tải thẻ đầu tiên
        });
