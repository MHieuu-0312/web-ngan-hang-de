/* === NỘI DUNG MỚI CHO: js/quiz-taking.js === */

// --- BIẾN TOÀN CỤC (GLOBAL STATE) ---
// Biến 'db' đã được định nghĩa trong file HTML
let allQuizQuestions = [];       // Mảng chứa 30 câu hỏi từ Firebase
let currentUserAnswers = [];     // Mảng lưu câu trả lời của người dùng (0, 1, 2, 3)
let currentQuestionIndex = 0;    // Vị trí câu hỏi hiện tại
let timerInterval;               // Biến để giữ bộ đếm thời gian
const TOTAL_TIME_SECONDS = 30 * 60; // 30 phút

// Ánh xạ ID môn học sang tên Tiếng Việt (bạn có thể thêm các môn khác)
const subjectNameMap = {
    'hoa-hoc': 'Bài kiểm tra Hóa học',
    'toan-hoc': 'Bài kiểm tra Toán học',
    'vat-ly': 'Bài kiểm tra Vật lý',
    'tieng-anh': 'Bài kiểm tra Tiếng Anh'
};

// --- KHỞI ĐỘNG BÀI THI (ENTRY POINT) ---
document.addEventListener('DOMContentLoaded', () => {
    // 1. Lấy subject từ URL
    const subjectId = getSubjectFromURL();

    if (subjectId) {
        // 2. Tải đề thi
        fetchQuiz(subjectId);
    } else {
        // 3. Nếu không có subject, báo lỗi và quay lại
        alert('Lỗi: Không tìm thấy môn học. Đang quay về trang chính.');
        window.location.href = 'student-dashboard.html';
    }
});

// --- LOGIC LẤY DỮ LIỆU TỪ FIREBASE ---

// Hàm 1: Lấy 'subject' từ URL (ví dụ: 'hoa-hoc')
function getSubjectFromURL() {
    const params = new URLSearchParams(window.location.search);
    return params.get('subject');
}

// Hàm 2: Xáo trộn một mảng (thuật toán Fisher-Yates)
function shuffleArray(array) {
    let currentIndex = array.length, randomIndex;
    while (currentIndex != 0) {
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex--;
        [array[currentIndex], array[randomIndex]] = [
            array[randomIndex], array[currentIndex]];
    }
    return array;
}

// Hàm 3: Hàm chính để tải câu hỏi
async function fetchQuiz(subjectId) {
    console.log(`Đang tải đề cho môn: ${subjectId}`);
    // TODO: Bạn có thể hiển thị một icon "đang tải" ở đây

    try {
        const questionBankRef = db.collection('subject').doc(subjectId).collection('questionBank');
        const snapshot = await questionBankRef.get();

        if (snapshot.empty) {
            console.error('Không tìm thấy câu hỏi nào cho môn này!');
            alert('Lỗi: Không tìm thấy đề thi cho môn học này.');
            return;
        }

        let allQuestions = [];
        snapshot.forEach(doc => {
            allQuestions.push({ id: doc.id, ...doc.data() });
        });

        // Xáo trộn và lấy 30 câu
        const shuffledQuestions = shuffleArray(allQuestions);
        const quizQuestions = shuffledQuestions.slice(0, 30);

        console.log("Đã tải và xáo trộn thành công:", quizQuestions);
        
        // --- KHỞI TẠO GIAO DIỆN BÀI THI ---
        initializeQuiz(subjectId, quizQuestions);

    } catch (error) {
        console.error('Lỗi nghiêm trọng khi tải câu hỏi:', error);
        alert('Đã xảy ra lỗi khi tải đề thi. Vui lòng thử lại.');
    }
}

// --- LOGIC GIAO DIỆN (UI) VÀ BÀI THI ---

// Hàm 4: Thiết lập giao diện ban đầu
function initializeQuiz(subjectId, questions) {
    allQuizQuestions = questions;
    currentUserAnswers = new Array(questions.length).fill(null);
    currentQuestionIndex = 0;

    // Cập nhật thông tin Header
    const subjectName = subjectNameMap[subjectId] || "Bài kiểm tra";
    const totalQuestions = questions.length;
    document.querySelector('header h1').textContent = subjectName;
    document.querySelector('header p').textContent = `${totalQuestions} câu • 30 phút`;

    // Cập nhật bảng thông tin
    document.getElementById('remainingCount').textContent = totalQuestions;
    document.getElementById('answeredCount').textContent = 0;

    // Tạo lưới câu hỏi (Question Grid)
    generateQuestionGrid(totalQuestions);

    // Tải câu hỏi đầu tiên
    loadQuestion(0);

    // Bắt đầu đếm thời gian
    startTimer(TOTAL_TIME_SECONDS);
}

// Hàm 5: Tạo lưới câu hỏi bên trái
function generateQuestionGrid(totalQuestions) {
    const grid = document.getElementById('questionGrid');
    grid.innerHTML = ''; // Xóa các câu hỏi tĩnh (nếu có)
    grid.className = 'grid grid-cols-5 gap-2'; // Đổi thành 5 cột cho đẹp hơn

    for (let i = 0; i < totalQuestions; i++) {
        const questionNav = document.createElement('button');
        questionNav.id = `q-nav-${i}`;
        questionNav.className = 'question-nav-item';
        questionNav.textContent = i + 1;
        questionNav.onclick = () => jumpToQuestion(i);
        grid.appendChild(questionNav);
    }
}

// Hàm 6: Tải nội dung câu hỏi và đáp án
function loadQuestion(index) {
    const question = allQuizQuestions[index];
    if (!question) return;

    // Cập nhật số câu hỏi
    document.getElementById('currentQuestionNumber').textContent = index + 1;

    // Cập nhật nội dung câu hỏi
    document.getElementById('questionText').innerHTML = question.text; // Dùng innerHTML để render (nếu có)

    // Cập nhật hình ảnh (nếu có)
    const imgContainer = document.getElementById('questionImage');
    if (question.imageUrl) { // Giả sử bạn có trường 'imageUrl'
        imgContainer.querySelector('img').src = question.imageUrl;
        imgContainer.classList.remove('hidden');
    } else {
        imgContainer.classList.add('hidden');
    }

    // Tạo các lựa chọn đáp án
    const optionsContainer = document.getElementById('answerOptions');
    optionsContainer.innerHTML = ''; // Xóa các đáp án tĩnh
    const optionLetters = ['A', 'B', 'C', 'D'];

    question.options.forEach((option, i) => {
        const optionDiv = document.createElement('div');
        optionDiv.className = 'answer-option border-2 border-gray-200 rounded-lg p-4 cursor-pointer';
        optionDiv.onclick = () => selectAnswer(i);

        // Kiểm tra xem đáp án này đã được chọn chưa
        if (currentUserAnswers[index] === i) {
            optionDiv.classList.add('selected'); // Thêm class 'selected' (bạn cần định nghĩa class này trong CSS)
        }

        optionDiv.innerHTML = `
            <div class="flex items-center">
                <span class="w-6 h-6 rounded-full border-2 border-gray-300 flex items-center justify-center mr-3 text-sm font-medium">${optionLetters[i]}</span>
                <span>${option}</span>
            </div>
        `;
        optionsContainer.appendChild(optionDiv);
    });

    // Cập nhật nút điều hướng (Trước/Sau)
    updateNavigationButtons();
    // Đánh dấu câu hỏi hiện tại trong lưới
    highlightCurrentQuestionInGrid();
}

// Hàm 7: Xử lý khi người dùng chọn đáp án
function selectAnswer(optionIndex) {
    // Lưu câu trả lời
    currentUserAnswers[currentQuestionIndex] = optionIndex;
    
    // Đánh dấu câu đã trả lời trong lưới
    document.getElementById(`q-nav-${currentQuestionIndex}`).classList.add('answered');
    
    // Tải lại câu hỏi để hiển thị lựa chọn
    loadQuestion(currentQuestionIndex);
    
    // Cập nhật tiến độ
    updateProgress();

    // Tự động chuyển câu tiếp theo (tùy chọn)
    // setTimeout(() => {
    //     nextQuestion();
    // }, 300);
}

// Hàm 8: Xóa đáp án đã chọn
function clearAnswer() {
    currentUserAnswers[currentQuestionIndex] = null;
    document.getElementById(`q-nav-${currentQuestionIndex}`).classList.remove('answered');
    loadQuestion(currentQuestionIndex);
    updateProgress();
}

// Hàm 9: Chuyển câu tiếp theo
function nextQuestion() {
    if (currentQuestionIndex < allQuizQuestions.length - 1) {
        currentQuestionIndex++;
        loadQuestion(currentQuestionIndex);
    }
}

// Hàm 10: Quay về câu trước
function previousQuestion() {
    if (currentQuestionIndex > 0) {
        currentQuestionIndex--;
        loadQuestion(currentQuestionIndex);
    }
}

// Hàm 11: Nhảy đến câu bất kỳ
function jumpToQuestion(index) {
    currentQuestionIndex = index;
    loadQuestion(index);
}

// Hàm 12: Cập nhật trạng thái (disabled) của nút Trước/Sau
function updateNavigationButtons() {
    document.getElementById('prevButton').disabled = (currentQuestionIndex === 0);
    document.getElementById('nextButton').disabled = (currentQuestionIndex === allQuizQuestions.length - 1);
}

// Hàm 13: Đánh dấu câu hiện tại trong lưới
function highlightCurrentQuestionInGrid() {
    // Xóa tất cả các trạng thái 'current'
    document.querySelectorAll('.question-nav-item').forEach(item => {
        item.classList.remove('current');
    });
    // Thêm 'current' cho câu hiện tại
    document.getElementById(`q-nav-${currentQuestionIndex}`).classList.add('current');
}

// Hàm 14: Cập nhật thanh tiến độ và số câu
function updateProgress() {
    const answeredCount = currentUserAnswers.filter(answer => answer !== null).length;
    const totalQuestions = allQuizQuestions.length;
    const percentage = (answeredCount / totalQuestions) * 100;

    document.getElementById('progressText').textContent = `${answeredCount}/${totalQuestions}`;
    document.getElementById('progressBar').style.width = `${percentage}%`;
    
    document.getElementById('answeredCount').textContent = answeredCount;
    document.getElementById('remainingCount').textContent = totalQuestions - answeredCount;
    
    // Cập nhật modal
    document.getElementById('modalAnsweredCount').textContent = `${answeredCount}/${totalQuestions}`;
}

// --- LOGIC ĐẾM THỜI GIAN VÀ MODAL ---
// (Các hàm này được gọi từ HTML, giữ nguyên tên)

function startTimer(duration) {
    let timer = duration, minutes, seconds;
    const timeDisplay = document.getElementById('timeDisplay');
    const timerCircle = document.getElementById('timerCircle');
    const circumference = timerCircle.r.baseVal.value * 2 * Math.PI;
    timerCircle.style.strokeDasharray = `${circumference} ${circumference}`;
    
    timerInterval = setInterval(() => {
        minutes = parseInt(timer / 60, 10);
        seconds = parseInt(timer % 60, 10);

        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        timeDisplay.textContent = minutes + ":" + seconds;
        document.getElementById('modalTimeRemaining').textContent = minutes + ":" + seconds;

        // Cập nhật vòng tròn
        const offset = circumference - (timer / duration) * circumference;
        timerCircle.style.strokeDashoffset = offset;

        // Cảnh báo 5 phút
        if (timer === 300) { // 5 phút
            document.getElementById('timeWarningModal').style.display = 'flex';
        }

        // Hết giờ
        if (--timer < 0) {
            clearInterval(timerInterval);
            alert("Hết giờ làm bài!");
            submitQuiz();
        }
    }, 1000);
}

function showSubmitModal() {
    document.getElementById('submitModal').style.display = 'flex';
}

function closeSubmitModal() {
    document.getElementById('submitModal').style.display = 'none';
}

function closeTimeWarning() {
    document.getElementById('timeWarningModal').style.display = 'none';
}

/* === Đặt trong: js/quiz-taking.js === */
/* === Thay thế hàm submitQuiz() cũ === */

/* === ĐẶT TRONG: js/quiz-taking.js === */
/* === THAY THẾ TOÀN BỘ HÀM submitQuiz() CŨ BẰNG HÀM NÀY === */

// Lưu ý: Hàm này không cần 'async' nữa vì dùng .then/.catch
/* === ĐẶT TRONG: js/quiz-taking.js === */
/* === THAY THẾ TOÀN BỘ HÀM submitQuiz() VÀ prepareAndRedirect() BẰNG PHIÊN BẢN NÀY === */

// Lưu ý: Hàm này không cần 'async' nữa
function submitQuiz() {
    clearInterval(timerInterval); // Dừng đồng hồ
    console.log("Nộp bài..."); // Log đơn giản

    // === 1. TÍNH ĐIỂM VÀ LẤY THÔNG TIN ===
    const timeDisplay = document.getElementById('timeDisplay').textContent;
    const timeParts = timeDisplay.split(':').map(Number);
    const timeRemainingSeconds = timeParts[0] * 60 + timeParts[1];
    const timeSpentSeconds = TOTAL_TIME_SECONDS - timeRemainingSeconds;

    let correctAnswersCount = 0;
    const totalQuestions = allQuizQuestions.length;
    allQuizQuestions.forEach((question, index) => {
        if (currentUserAnswers[index] !== null && Number(currentUserAnswers[index]) === Number(question.correctAnswer)) {
            correctAnswersCount++;
        }
    });

    const currentScore = parseFloat(((correctAnswersCount / totalQuestions) * 10).toFixed(1));
    const scoreFormatted = currentScore.toFixed(1);
    const subjectId = getSubjectFromURL();
    // ===================================

    // === 2. LƯU TIẾN TRÌNH VÀO FIREBASE ===
    const user = auth.currentUser;
    if (user) {
        const userId = user.uid;
        const userDocRef = db.collection('users').doc(userId);

        userDocRef.get().then(userDoc => {
            let updatePromise;
            let finalAttempts = 1; // Khởi tạo giá trị mặc định
            let finalHighestScore = currentScore; // Khởi tạo giá trị mặc định

            if (!userDoc.exists) {
                // Tạo mới nếu chưa có
                const initialProgress = {};
                initialProgress[subjectId] = {
                    highestScore: currentScore,
                    attempts: 1,
                    lastAttemptAt: firebase.firestore.FieldValue.serverTimestamp()
                };
                updatePromise = userDocRef.set({
                    name: user.displayName || user.email || "New User",
                    email: user.email || "",
                    role: 'student',
                    createdAt: firebase.firestore.FieldValue.serverTimestamp(),
                    subjectProgress: initialProgress
                });
            } else {
                // Cập nhật nếu đã có
                const userData = userDoc.data();
                const currentSubjectData = (userData.subjectProgress && userData.subjectProgress[subjectId]) || { highestScore: 0, attempts: 0 };

                finalAttempts = currentSubjectData.attempts + 1;
                finalHighestScore = Math.max(currentSubjectData.highestScore, currentScore);

                const updateData = {};
                updateData[`subjectProgress.${subjectId}.highestScore`] = finalHighestScore;
                updateData[`subjectProgress.${subjectId}.attempts`] = finalAttempts;
                updateData[`subjectProgress.${subjectId}.lastAttemptAt`] = firebase.firestore.FieldValue.serverTimestamp();
                updatePromise = userDocRef.update(updateData);
            }

            // Xử lý sau khi set/update
            return updatePromise.then(() => {
                 console.log(`Firebase: Lưu tiến trình môn ${subjectId} thành công.`);
                 // Chuyển hướng sau khi lưu thành công
                 prepareAndRedirect(scoreFormatted, correctAnswersCount, timeSpentSeconds, subjectId);
            });

        }).catch(error => {
            console.error("Firebase: Lỗi khi lưu tiến trình:", error); // Chỉ log lỗi thực sự
            alert("Lưu tiến trình thất bại. Vui lòng kiểm tra Console (F12).");
            // Chuyển hướng ngay cả khi lỗi
            prepareAndRedirect(scoreFormatted, correctAnswersCount, timeSpentSeconds, subjectId);
        });

    } else {
        console.warn("User chưa đăng nhập, bỏ qua lưu Firebase.");
        // Chuyển hướng ngay
        prepareAndRedirect(scoreFormatted, correctAnswersCount, timeSpentSeconds, subjectId);
    }
}

// Hàm hiển thị đáp án
function prepareAndRedirect(scoreFormatted, correctAnswersCount, timeSpentSeconds, subjectId) {
    console.log("Chuẩn bị chuyển hướng đến trang kết quả...");
    const quizResultDataForRedirect = {
        score: scoreFormatted,
        correctCount: correctAnswersCount,
        totalQuestions: allQuizQuestions.length,
        incorrectCount: allQuizQuestions.length - correctAnswersCount,
        unansweredCount: currentUserAnswers.filter(a => a === null).length,
        timeSpent: timeSpentSeconds,
        subjectId: subjectId,
        subjectName: subjectNameMap[subjectId] || "Bài kiểm tra",
        questions: allQuizQuestions,
        userAnswers: currentUserAnswers
    };

    try {
        sessionStorage.setItem('quizResultData', JSON.stringify(quizResultDataForRedirect));
    } catch (e) {
        console.error("Lỗi lưu sessionStorage:", e);
        alert("Lỗi nghiêm trọng khi chuẩn bị hiển thị kết quả.");
        return;
    }

    alert("Nộp bài thành công! Đang chuyển đến trang kết quả...");
    window.location.href = 'quiz-results.html';
}

// --- LOGIC SIDEBAR --
function toggleSidebar() {
    const sidebar = document.getElementById('questionSidebar');
    const icon = document.getElementById('sidebarIcon');
    if (!sidebar || !icon) return;

    sidebar.classList.toggle('sidebar-expanded');
    sidebar.classList.toggle('sidebar-collapsed');

    if (sidebar.classList.contains('sidebar-collapsed')) {
        icon.classList.remove('fa-chevron-left');
        icon.classList.add('fa-chevron-right');
    } else {
        icon.classList.remove('fa-chevron-right');
        icon.classList.add('fa-chevron-left');
    }
}