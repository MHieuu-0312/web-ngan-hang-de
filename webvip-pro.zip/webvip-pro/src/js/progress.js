/* ========================================
   PROGRESS PAGE JAVASCRIPT
   Theo dõi tiến độ học tập
   ======================================== */

// Update progress ring
function updateProgressRing(elementId, percentage) {
    const circle = document.querySelector(`#${elementId} .progress-ring__circle`);
    if (!circle) return;
    
    const radius = circle.r.baseVal.value;
    const circumference = radius * 2 * Math.PI;
    const offset = circumference - (percentage / 100) * circumference;
    
    circle.style.strokeDasharray = `${circumference} ${circumference}`;
    circle.style.strokeDashoffset = offset;
}

// Toggle time period view
function toggleTimePeriod(period) {
    const periodBtns = document.querySelectorAll('.period-btn');
    periodBtns.forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.period === period) {
            btn.classList.add('active');
        }
    });
    
    // Update data based on period
    updateProgressData(period);
}

// Update progress data
function updateProgressData(period) {
    // This would fetch data from backend based on time period
    console.log('Updating progress data for period:', period);
    
    // Simulate data update
    if (typeof Chart !== 'undefined') {
        updateProgressCharts(period);
    }
}

// Initialize progress charts
function initProgressCharts() {
    const weeklyCtx = document.getElementById('weeklyProgressChart');
    if (weeklyCtx && typeof Chart !== 'undefined') {
        new Chart(weeklyCtx, {
            type: 'line',
            data: {
                labels: ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'],
                datasets: [{
                    label: 'Thời gian học (giờ)',
                    data: [2, 1.5, 3, 2.5, 2, 3.5, 1],
                    borderColor: '#2563eb',
                    backgroundColor: 'rgba(37, 99, 235, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
    }
    
    const subjectCtx = document.getElementById('subjectProgressChart');
    if (subjectCtx && typeof Chart !== 'undefined') {
        new Chart(subjectCtx, {
            type: 'radar',
            data: {
                labels: ['Toán', 'Văn', 'Anh', 'Lý', 'Hóa', 'Sinh'],
                datasets: [{
                    label: 'Tiến độ (%)',
                    data: [75, 60, 85, 70, 55, 80],
                    borderColor: '#2563eb',
                    backgroundColor: 'rgba(37, 99, 235, 0.2)'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    r: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });
    }
}

function updateProgressCharts(period) {
    // Update chart data based on selected period
    console.log('Updating charts for period:', period);
}

// Initialize achievement progress
function initAchievements() {
    const achievements = document.querySelectorAll('.achievement-item');
    achievements.forEach((achievement, index) => {
        setTimeout(() => {
            achievement.classList.add('unlocked');
        }, index * 100);
    });
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    // Initialize progress rings
    updateProgressRing('mathProgress', 75);
    updateProgressRing('literatureProgress', 60);
    updateProgressRing('englishProgress', 85);
    
    // Initialize charts
    if (typeof Chart !== 'undefined') {
        initProgressCharts();
    }
    
    // Initialize achievements
    initAchievements();
    
    console.log('Progress page initialized');
});
