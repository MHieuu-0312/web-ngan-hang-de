# 📚 SCRIBBLE - Nền tảng Học tập Trực tuyến

> Ứng dụng web giúp học sinh làm bài kiểm tra, ôn luyện và theo dõi tiến độ học tập

---

## 📁 CẤU TRÚC DỰ ÁN

```
scribble-app/
│
├── index.html                  # Trang chủ
├── login.html                  # Đăng nhập
├── signup.html                 # Đăng ký
│
├── student-dashboard.html      # Dashboard học sinh
├── student-quizzes.html        # Danh sách bài kiểm tra
├── student-practice.html       # Ôn luyện
├── student-results.html        # Kết quả
├── student-progress.html       # Tiến độ học tập
│
├── quiz-taking.html            # Làm bài kiểm tra
├── quiz-results.html           # Kết quả bài kiểm tra
│
├── css/                        # Thư mục CSS
│   ├── style.css              # CSS chung
│   ├── dashboard.css          # CSS cho dashboard
│   └── quiz.css               # CSS cho quiz
│
├── js/                         # Thư mục JavaScript
│   ├── main.js                # JS chung
│   ├── auth.js                # Đăng nhập/Đăng ký
│   ├── dashboard.js           # Dashboard
│   └── quiz.js                # Quiz
│
└── docs/                       # Tài liệu
    └── HUONG_DAN_SU_DUNG.md   # Hướng dẫn sử dụng
```

---

## 🚀 CÁCH SỬ DỤNG

### Bước 1: Mở file trong trình duyệt

```
Cách 1: Double-click vào index.html
Cách 2: Right-click → Open with → Chrome/Firefox/Safari
```

### Bước 2: Khám phá ứng dụng

1. **Trang chủ** (`index.html`) - Giới thiệu về Scribble
2. **Đăng ký** (`signup.html`) - Tạo tài khoản
3. **Đăng nhập** (`login.html`) - Đăng nhập vào hệ thống
4. **Dashboard** (`student-dashboard.html`) - Xem tổng quan
5. **Bài kiểm tra** (`student-quizzes.html`) - Danh sách bài thi
6. **Làm bài** (`quiz-taking.html`) - Làm bài kiểm tra
7. **Kết quả** (`quiz-results.html`) - Xem kết quả

---

## 🎨 CÔNG NGHỆ SỬ DỤNG

### Frontend
- **HTML5** - Cấu trúc trang web
- **CSS3** - Styling và animations
- **JavaScript** - Chức năng tương tác
- **Tailwind CSS** - Framework CSS (qua CDN)

### Thư viện
- **Font Awesome** - Icons
- **Chart.js** - Biểu đồ (trong dashboard)

### Đặc điểm
- ✅ Không cần cài đặt
- ✅ Không cần server
- ✅ Chạy trực tiếp trong trình duyệt
- ✅ Responsive (mobile-friendly)

---

## 📖 GIẢI THÍCH CẤU TRÚC

### 1. File HTML
Mỗi file HTML là một trang riêng biệt:
- `index.html` - Trang chủ với giới thiệu
- `login.html` - Form đăng nhập
- `student-dashboard.html` - Dashboard cho học sinh
- v.v.

### 2. Thư mục CSS (`css/`)
Chứa các file CSS được tách riêng:
- `style.css` - CSS chung (buttons, cards, animations)
- `dashboard.css` - CSS riêng cho dashboard
- `quiz.css` - CSS riêng cho quiz

### 3. Thư mục JS (`js/`)
Chứa các file JavaScript theo chức năng:
- `main.js` - JS chung (menu, scroll, animations)
- `auth.js` - Đăng nhập/Đăng ký
- `dashboard.js` - Dashboard và charts
- `quiz.js` - Quiz functionality

---

## 💡 HƯỚNG DẪN CHO GIÁO SƯ

### Xem code HTML
```html
<!-- Mở bất kỳ file .html nào -->
<!-- HTML rất rõ ràng với comments giải thích -->
```

### Xem code CSS
```css
/* Mở file trong thư mục css/ */
/* Mỗi phần có comment giải thích */
```

### Xem code JavaScript
```javascript
// Mở file trong thư mục js/
// Có comment và function names rõ ràng
```

### Chạy demo
1. Mở `index.html` để xem trang chủ
2. Click "Đăng nhập" hoặc "Đăng ký"
3. Nhập thông tin bất kỳ và submit
4. Sẽ được redirect đến dashboard

---

## 🎯 TÍNH NĂNG CHÍNH

### 1. Landing Page
- Hero section với background đẹp
- Giới thiệu 3 tính năng chính
- Hướng dẫn 3 bước sử dụng
- Testimonials (đánh giá)
- Call-to-action

### 2. Authentication
- Form đăng nhập
- Form đăng ký
- Validation (kiểm tra input)
- Responsive design

### 3. Student Dashboard
- Thống kê tổng quan (stats)
- Bài kiểm tra gần đây
- Tiến độ học tập
- Thành tích

### 4. Quiz Functionality
- Danh sách bài kiểm tra
- Làm bài với timer
- Navigation giữa các câu hỏi
- Hiển thị kết quả chi tiết

### 5. Progress Tracking
- Charts và graphs
- Điểm số theo môn
- Lịch sử làm bài
- Phân tích tiến độ

---

## 📱 RESPONSIVE DESIGN

### Desktop (> 1024px)
- Layout 3-4 cột
- Menu đầy đủ
- Spacing rộng

### Tablet (768px - 1024px)
- Layout 2 cột
- Menu thu gọn

### Mobile (< 768px)
- Layout 1 cột
- Hamburger menu
- Touch-friendly

---

## 🔍 CODE HIGHLIGHTS

### HTML Structure
```html
<!DOCTYPE html>
<html lang="vi">
<head>
    <!-- Meta tags, CSS links -->
</head>
<body>
    <!-- Header, Main content, Footer -->
    <!-- JavaScript ở cuối -->
</body>
</html>
```

### CSS Organization
```css
/* === SECTION NAME === */
.class-name {
    property: value;
}
```

### JavaScript Functions
```javascript
/**
 * Function description
 */
function functionName() {
    // Clear code with comments
}
```

---

## 🎓 HỌC TỪ DỰ ÁN NÀY

### HTML
- Semantic HTML5
- Form elements
- Responsive images
- Navigation

### CSS
- Flexbox & Grid
- Animations
- Responsive design
- Tailwind CSS

### JavaScript
- DOM manipulation
- Event handling
- Form validation
- Local storage (concept)

---

## 📞 HỖ TRỢ

### Xem tài liệu chi tiết
```
docs/HUONG_DAN_SU_DUNG.md          - Hướng dẫn sử dụng
docs/LỖI_NAVIGATION_VÀ_CÁCH_SỬA.md - Giải thích lỗi navigation
```

### Code comments
- Mọi file đều có comments giải thích
- Function names rõ ràng
- Variable names dễ hiểu

### Lỗi đã sửa
✅ **Navigation trong sidebar** - Đã sửa links để chuyển trang đúng cách

---

## ✨ ĐẶC ĐIỂM NỔI BẬT

### Dễ hiểu
- Code rõ ràng, có comments
- Cấu trúc đơn giản
- Phân chia file logic

### Chuyên nghiệp
- Responsive design
- Smooth animations
- User-friendly interface

### Hoàn chỉnh
- 10 trang HTML
- 3 file CSS
- 4 file JavaScript
- Đầy đủ chức năng

---

## 🎉 KẾT LUẬN

**Scribble** là ứng dụng web hoàn chỉnh được xây dựng bằng:
- ✅ HTML/CSS/JavaScript thuần túy
- ✅ Cấu trúc rõ ràng, dễ hiểu
- ✅ Code có comment đầy đủ
- ✅ Sẵn sàng trình bày

**Perfect for presentation to professors!** 🎓

---

**Developed by: [Your Name]**  
**Year: 2025**  
**License: Educational Use**
