import { motion } from 'motion/react';
import { UserPlus, FileEdit, BarChart3 } from 'lucide-react';

export function HowItWorksSection() {
  const steps = [
    {
      icon: <UserPlus className="w-8 h-8" />,
      title: 'Đăng ký tài khoản',
      description: 'Tạo tài khoản miễn phí chỉ trong vài giây. Chọn vai trò phù hợp: Giáo viên hoặc Học sinh.',
    },
    {
      icon: <FileEdit className="w-8 h-8" />,
      title: 'Tạo hoặc tham gia',
      description:
        'Giáo viên tạo đề thi và bài tập. Học sinh tham gia lớp học và bắt đầu làm bài ngay lập tức.',
    },
    {
      icon: <BarChart3 className="w-8 h-8" />,
      title: 'Theo dõi tiến độ',
      description: 'Xem kết quả chi tiết, phân tích điểm mạnh yếu và cải thiện hiệu suất học tập liên tục.',
    },
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl text-gray-900 mb-4">
            Cách thức hoạt động
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Chỉ với 3 bước đơn giản, bạn đã có thể bắt đầu hành trình học tập hiệu quả
          </p>
        </motion.div>

        <div className="relative">
          {/* Timeline Line */}
          <div className="hidden md:block absolute top-1/2 left-0 right-0 h-1 bg-blue-200 transform -translate-y-1/2" />

          <div className="grid md:grid-cols-3 gap-8 relative">
            {steps.map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                className="relative"
              >
                {/* Step Card */}
                <div className="bg-white border-2 border-gray-200 rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-shadow relative z-10">
                  {/* Step Number */}
                  <div className="absolute -top-4 -left-4 w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center text-xl z-20">
                    {index + 1}
                  </div>

                  {/* Icon */}
                  <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center text-blue-600 mb-6 mx-auto">
                    {step.icon}
                  </div>

                  {/* Content */}
                  <h3 className="text-xl text-gray-900 mb-3 text-center">{step.title}</h3>
                  <p className="text-gray-600 text-center">{step.description}</p>
                </div>

                {/* Connector (for desktop) */}
                {index < steps.length - 1 && (
                  <motion.div
                    initial={{ scaleX: 0 }}
                    whileInView={{ scaleX: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.6, delay: index * 0.2 + 0.3 }}
                    className="hidden md:block absolute top-1/2 left-full w-full h-1 bg-blue-600 transform -translate-y-1/2 origin-left"
                    style={{ width: 'calc(100% - 2rem)' }}
                  />
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
