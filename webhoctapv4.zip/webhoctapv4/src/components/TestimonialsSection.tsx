import { motion } from 'motion/react';
import { Card } from './ui/card';
import { Star } from 'lucide-react';
import { useState, useEffect } from 'react';

export function TestimonialsSection() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const testimonials = [
    {
      name: 'Nguyễn Thị Mai',
      role: 'Giáo viên Toán, THPT Lê Quý Đôn',
      avatar: 'https://i.pravatar.cc/150?img=1',
      quote:
        'Scribble đã giúp tôi tiết kiệm rất nhiều thời gian trong việc chuẩn bị đề thi. Tôi có thể tập trung nhiều hơn vào việc giảng dạy và hỗ trợ học sinh.',
      rating: 5,
    },
    {
      name: 'Trần Văn Minh',
      role: 'Học sinh lớp 12A1',
      avatar: 'https://i.pravatar.cc/150?img=12',
      quote:
        'Với Scribble, tôi có thể luyện tập bất cứ lúc nào. Hệ thống theo dõi tiến độ giúp tôi biết mình cần cải thiện ở đâu. Điểm số của tôi đã tăng đáng kể!',
      rating: 5,
    },
    {
      name: 'Lê Thị Hương',
      role: 'Giáo viên Vật lý, THCS Nam Từ Liêm',
      avatar: 'https://i.pravatar.cc/150?img=5',
      quote:
        'Giao diện rất dễ sử dụng và tính năng tự động chấm bài là một bước đột phá. Tôi có thể theo dõi kết quả của cả lớp chỉ trong vài phút.',
      rating: 5,
    },
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % testimonials.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [testimonials.length]);

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl text-gray-900 mb-4">
            Người dùng nói gì về chúng tôi
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Hàng ngàn giáo viên và học sinh đã tin tưởng sử dụng Scribble
          </p>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          <div className="relative h-96">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{
                  opacity: currentIndex === index ? 1 : 0,
                  scale: currentIndex === index ? 1 : 0.8,
                  zIndex: currentIndex === index ? 10 : 0,
                }}
                transition={{ duration: 0.5 }}
                className="absolute inset-0"
              >
                <Card className="p-8 md:p-12 shadow-2xl bg-gradient-to-br from-white to-blue-50 border-2 border-blue-100">
                  <div className="flex items-center mb-6">
                    <img
                      src={testimonial.avatar}
                      alt={testimonial.name}
                      className="w-16 h-16 rounded-full mr-4"
                    />
                    <div>
                      <h4 className="text-xl text-gray-900">{testimonial.name}</h4>
                      <p className="text-gray-600">{testimonial.role}</p>
                    </div>
                  </div>

                  <div className="flex mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 text-yellow-400 fill-yellow-400" />
                    ))}
                  </div>

                  <p className="text-lg text-gray-700 italic leading-relaxed">
                    "{testimonial.quote}"
                  </p>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* Indicators */}
          <div className="flex justify-center mt-8 space-x-2">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`w-3 h-3 rounded-full transition-all ${
                  currentIndex === index ? 'bg-blue-600 w-8' : 'bg-gray-300'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
