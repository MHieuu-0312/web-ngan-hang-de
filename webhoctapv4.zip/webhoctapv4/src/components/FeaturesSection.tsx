import { motion } from 'motion/react';
import { useEffect, useState, useRef } from 'react';
import { Database, Zap, TrendingUp } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface Feature {
  icon: React.ReactNode;
  title: string;
  description: string;
  image: string;
  reverse?: boolean;
}

interface FeaturesSectionProps {
  images: {
    questionBank: string;
    testCreation: string;
    analytics: string;
  };
}

export function FeaturesSection({ images }: FeaturesSectionProps) {
  const features: Feature[] = [
    {
      icon: <Database className="w-12 h-12 text-blue-600" />,
      title: 'Ngân hàng câu hỏi đa dạng',
      description:
        'Truy cập hàng ngàn câu hỏi được phân loại theo môn học, chủ đề và độ khó. Dễ dàng lọc và tìm kiếm câu hỏi phù hợp với nhu cầu giảng dạy của bạn.',
      image: images.questionBank,
      reverse: false,
    },
    {
      icon: <Zap className="w-12 h-12 text-blue-600" />,
      title: 'Tạo đề thi thông minh trong vài giây',
      description:
        'Chọn các tiêu chí về môn học, độ khó và số lượng câu hỏi, hệ thống sẽ tự động tạo ra bộ đề thi hoàn chỉnh. Tiết kiệm hàng giờ chuẩn bị.',
      image: images.testCreation,
      reverse: true,
    },
    {
      icon: <TrendingUp className="w-12 h-12 text-blue-600" />,
      title: 'Theo dõi kết quả tức thì',
      description:
        'Xem báo cáo chi tiết về tiến độ học tập của học sinh với biểu đồ trực quan. Phát hiện điểm mạnh, điểm yếu để điều chỉnh phương pháp giảng dạy.',
      image: images.analytics,
      reverse: false,
    },
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl text-gray-900 mb-4">
            Tính năng nổi bật
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Khám phá các công cụ mạnh mẽ giúp việc dạy và học trở nên dễ dàng hơn bao giờ hết
          </p>
        </motion.div>

        <div className="space-y-24">
          {features.map((feature, index) => (
            <FeatureItem key={index} feature={feature} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}

function FeatureItem({ feature, index }: { feature: Feature; index: number }) {
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => {
      if (ref.current) {
        observer.unobserve(ref.current);
      }
    };
  }, []);

  return (
    <div
      ref={ref}
      className={`grid md:grid-cols-2 gap-12 items-center ${
        feature.reverse ? 'md:flex-row-reverse' : ''
      }`}
    >
      <motion.div
        initial={{ opacity: 0, x: feature.reverse ? 50 : -50 }}
        animate={isVisible ? { opacity: 1, x: 0 } : {}}
        transition={{ duration: 0.6, delay: 0.2 }}
        className={feature.reverse ? 'md:order-2' : ''}
      >
        <div className="mb-6">{feature.icon}</div>
        <h3 className="text-2xl md:text-3xl text-gray-900 mb-4">{feature.title}</h3>
        <p className="text-lg text-gray-600">{feature.description}</p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, x: feature.reverse ? -50 : 50 }}
        animate={isVisible ? { opacity: 1, x: 0 } : {}}
        transition={{ duration: 0.6, delay: 0.4 }}
        className={feature.reverse ? 'md:order-1' : ''}
      >
        <div className="rounded-2xl overflow-hidden shadow-2xl">
          <ImageWithFallback
            src={feature.image}
            alt={feature.title}
            className="w-full h-auto"
          />
        </div>
      </motion.div>
    </div>
  );
}
