import { motion } from 'motion/react';
import { useState } from 'react';
import { GraduationCap, Users, Clock, CheckCircle, Target, TrendingUp } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface ForYouSectionProps {
  teacherImage: string;
  studentImage: string;
}

export function ForYouSection({ teacherImage, studentImage }: ForYouSectionProps) {
  const [activeTab, setActiveTab] = useState<'teacher' | 'student'>('teacher');

  const teacherBenefits = [
    { icon: <Clock className="w-6 h-6" />, text: 'Tiết kiệm hàng giờ chuẩn bị đề thi' },
    { icon: <CheckCircle className="w-6 h-6" />, text: 'Tự động chấm bài và thống kê kết quả' },
    { icon: <Users className="w-6 h-6" />, text: 'Quản lý nhiều lớp học dễ dàng' },
    { icon: <Target className="w-6 h-6" />, text: 'Tùy chỉnh nội dung theo nhu cầu' },
  ];

  const studentBenefits = [
    { icon: <GraduationCap className="w-6 h-6" />, text: 'Luyện tập mọi lúc, mọi nơi' },
    { icon: <TrendingUp className="w-6 h-6" />, text: 'Theo dõi sự tiến bộ của bản thân' },
    { icon: <Target className="w-6 h-6" />, text: 'Nhận phản hồi tức thời' },
    { icon: <CheckCircle className="w-6 h-6" />, text: 'Ôn luyện theo độ khó phù hợp' },
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-blue-50 to-purple-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-5xl text-gray-900 mb-4">
            Dành riêng cho bạn
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Scribble được thiết kế để đáp ứng nhu cầu của cả giáo viên và học sinh
          </p>
        </motion.div>

        {/* Tab Switcher */}
        <div className="flex justify-center mb-12">
          <div className="bg-white rounded-full p-1 shadow-lg inline-flex">
            <button
              onClick={() => setActiveTab('teacher')}
              className={`px-8 py-3 rounded-full transition-all ${
                activeTab === 'teacher'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Dành cho Giáo viên
            </button>
            <button
              onClick={() => setActiveTab('student')}
              className={`px-8 py-3 rounded-full transition-all ${
                activeTab === 'student'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Dành cho Học sinh
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h3 className="text-2xl md:text-3xl text-gray-900 mb-6">
              {activeTab === 'teacher' ? 'Giải pháp cho Giáo viên' : 'Giải pháp cho Học sinh'}
            </h3>
            <p className="text-lg text-gray-600 mb-8">
              {activeTab === 'teacher'
                ? 'Tập trung vào giảng dạy, để Scribble lo phần còn lại. Tạo đề thi, chấm bài và theo dõi tiến độ học sinh một cách tự động và hiệu quả.'
                : 'Học tập theo cách riêng của bạn. Luyện tập với hàng ngàn câu hỏi, kiểm tra kiến thức và cải thiện kết quả học tập mỗi ngày.'}
            </p>

            <div className="space-y-4">
              {(activeTab === 'teacher' ? teacherBenefits : studentBenefits).map(
                (benefit, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    className="flex items-center space-x-4 bg-white p-4 rounded-xl shadow-sm"
                  >
                    <div className="text-blue-600">{benefit.icon}</div>
                    <span className="text-gray-700">{benefit.text}</span>
                  </motion.div>
                )
              )}
            </div>
          </motion.div>

          <motion.div
            key={`image-${activeTab}`}
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="relative"
          >
            <div className="rounded-2xl overflow-hidden shadow-2xl">
              <ImageWithFallback
                src={activeTab === 'teacher' ? teacherImage : studentImage}
                alt={activeTab === 'teacher' ? 'Teacher' : 'Student'}
                className="w-full h-auto"
              />
            </div>
            {/* Decorative Element */}
            <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-blue-600 rounded-full opacity-10 blur-3xl" />
            <div className="absolute -top-6 -left-6 w-32 h-32 bg-purple-600 rounded-full opacity-10 blur-3xl" />
          </motion.div>
        </div>
      </div>
    </section>
  );
}
