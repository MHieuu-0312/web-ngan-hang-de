# 📖 HƯỚNG DẪN SỬ DỤNG SCRIBBLE

> Tài liệu chi tiết về cách sử dụng và giải thích code

---

## 📑 MỤC LỤC

1. [Giới thiệu](#giới-thiệu)
2. [Cấu trúc dự án](#cấu-trúc-dự-án)
3. [Giải thích từng file](#giải-thích-từng-file)
4. [Hướng dẫn chạy](#hướng-dẫn-chạy)
5. [Giải thích code](#giải-thích-code)
6. [Câu hỏi thường gặp](#câu-hỏi-thường-gặp)

---

## 🎯 GIỚI THIỆU

**Scribble** là nền tảng học tập trực tuyến cho học sinh với các tính năng:

### Chức năng chính:
1. ✅ Làm bài kiểm tra trực tuyến
2. ✅ Ôn luyện theo chủ đề
3. ✅ Theo dõi kết quả và tiến độ
4. ✅ Xem thống kê chi tiết

### Công nghệ:
- **HTML** - Cấu trúc
- **CSS** - Giao diện
- **JavaScript** - Tương tác

---

## 📁 CẤU TRÚC DỰ ÁN

```
scribble-app/
│
├── 📄 TRANG HTML (10 files)
│   ├── index.html              ← Trang chủ
│   ├── login.html              ← Đăng nhập
│   ├── signup.html             ← Đăng ký
│   ├── student-dashboard.html  ← Dashboard
│   ├── student-quizzes.html    ← Danh sách bài thi
│   ├── student-practice.html   ← Ôn luyện
│   ├── student-results.html    ← Kết quả
│   ├── student-progress.html   ← Tiến độ
│   ├── quiz-taking.html        ← Làm bài
│   └── quiz-results.html       ← Kết quả chi tiết
│
├── 🎨 CSS (3 files)
│   ├── style.css              ← CSS chung
│   ├── dashboard.css          ← CSS dashboard
│   └── quiz.css               ← CSS quiz
│
├── ⚙️ JAVASCRIPT (4 files)
│   ├── main.js                ← JS chung
│   ├── auth.js                ← Đăng nhập/ký
│   ├── dashboard.js           ← Dashboard
│   └── quiz.js                ← Quiz
│
└── 📚 DOCS
    └── HUONG_DAN_SU_DUNG.md   ← File này
```

---

## 📄 GIẢI THÍCH TỪNG FILE

### 1. TRANG HTML

#### `index.html` - Trang chủ
**Mục đích:** Landing page giới thiệu Scribble

**Sections:**
- Header (menu navigation)
- Hero section (phần đầu với background đẹp)
- Features (3 tính năng chính)
- How it works (3 bước sử dụng)
- Testimonials (đánh giá từ học sinh)
- Footer (liên kết và thông tin)

**Links đến:**
- `css/style.css` - Styling
- `js/main.js` - JavaScript

**Code quan trọng:**
```html
<!-- Link CSS -->
<link rel="stylesheet" href="css/style.css">

<!-- Link JavaScript -->
<script src="js/main.js"></script>
```

---

#### `login.html` - Trang đăng nhập
**Mục đích:** Form đăng nhập

**Elements:**
- Email input
- Password input
- Remember me checkbox
- Submit button

**Links đến:**
- `css/style.css`
- `js/auth.js` - Xử lý đăng nhập

**Validation:**
- Kiểm tra email format
- Kiểm tra password không rỗng

---

#### `signup.html` - Trang đăng ký
**Mục đích:** Form đăng ký tài khoản

**Elements:**
- Full name input
- Email input
- Password input
- Confirm password
- Terms checkbox

**Validation:**
- Tất cả field phải được điền
- Email hợp lệ
- Password ít nhất 6 ký tự
- Password khớp nhau

---

#### `student-dashboard.html` - Dashboard
**Mục đích:** Trang tổng quan cho học sinh

**Sections:**
- Sidebar navigation
- Stats cards (4 cards hiển thị thống kê)
- Recent quizzes
- Learning progress
- Achievements

**Charts:** Không (chỉ progress bars)

---

#### `student-quizzes.html` - Danh sách bài kiểm tra
**Mục đích:** Hiển thị tất cả bài kiểm tra có sẵn

**Features:**
- Filter theo môn học
- Filter theo độ khó
- Search bar
- Quiz cards với thông tin

**Buttons:**
- "Bắt đầu làm bài" → `quiz-taking.html`

---

#### `student-practice.html` - Ôn luyện
**Mục đích:** Luyện tập theo chủ đề

**Features:**
- Chọn môn học
- Chọn chủ đề cụ thể
- Chọn độ khó
- Chọn số câu hỏi

---

#### `student-results.html` - Kết quả
**Mục đích:** Xem lịch sử kết quả các bài đã làm

**Features:**
- Bảng results history
- Score visualization
- Filter theo ngày
- Charts (Chart.js)

**Charts:**
- Line chart (điểm theo thời gian)
- Bar chart (điểm theo môn)

---

#### `student-progress.html` - Tiến độ
**Mục đích:** Theo dõi tiến độ tổng thể

**Features:**
- Overall progress
- Subject breakdown
- Achievements badges
- Charts

**Charts:**
- Progress line chart
- Subject comparison
- Activity tracking

---

#### `quiz-taking.html` - Làm bài
**Mục đích:** Giao diện làm bài kiểm tra

**Features:**
- Timer countdown (đếm ngược thời gian)
- Question display
- Answer options (lựa chọn đáp án)
- Question navigation (chuyển câu hỏi)
- Mark for review (đánh dấu để xem lại)
- Progress bar

**JavaScript:** `js/quiz.js`

---

#### `quiz-results.html` - Kết quả chi tiết
**Mục đích:** Hiển thị kết quả sau khi làm bài

**Features:**
- Score display (hiển thị điểm)
- Performance breakdown
- Question review (xem lại từng câu)
- Correct/Incorrect answers
- Explanations (giải thích)
- Action buttons (retry, continue)

---

### 2. CSS FILES

#### `css/style.css` - CSS chung
**Chứa:**
- Animations (@keyframes)
- Utility classes (.fade-in, .hover-scale)
- Buttons (.btn-primary, .btn-outline)
- Cards (.card, .feature-card)
- Header styles
- Mobile menu
- Form inputs

**Sử dụng bởi:** Tất cả HTML files

---

#### `css/dashboard.css` - CSS Dashboard
**Chứa:**
- Sidebar styles
- Subject icons
- Achievement badges
- Quiz difficulty badges
- Progress bars
- Stats cards

**Sử dụng bởi:** 
- `student-dashboard.html`
- `student-quizzes.html`
- `student-results.html`
- `student-progress.html`

---

#### `css/quiz.css` - CSS Quiz
**Chứa:**
- Quiz timer styles
- Question navigation
- Answer options
- Quiz progress bar
- Results display
- Score display

**Sử dụng bởi:**
- `quiz-taking.html`
- `quiz-results.html`

---

### 3. JAVASCRIPT FILES

#### `js/main.js` - JavaScript chung
**Functions:**

```javascript
// 1. Toggle mobile menu
function toggleMobileMenu()

// 2. Header scroll effect
window.addEventListener('scroll', ...)

// 3. Tab switching
function switchTab(tab)

// 4. Testimonials carousel
function showTestimonial(index)

// 5. Scroll reveal animation
function reveal()

// 6. Smooth scrolling
```

**Sử dụng bởi:** `index.html`

---

#### `js/auth.js` - Authentication
**Functions:**

```javascript
// 1. Email validation
function validateEmail(email)

// 2. Password validation
function validatePassword(password)

// 3. Show/clear errors
function showError(inputId, message)
function clearError(inputId)

// 4. Login handler
function handleLogin(event)

// 5. Signup handler
function handleSignup(event)

// 6. Toggle password visibility
function togglePassword(inputId)
```

**Sử dụng bởi:** 
- `login.html`
- `signup.html`

---

#### `js/dashboard.js` - Dashboard
**Functions:**

```javascript
// 1. Toggle sidebar (mobile)
function toggleSidebar()

// 2. Show section
function showSection(sectionName)

// 3. Initialize charts
function initProgressChart()
function initSubjectChart()
function initPerformanceChart()
```

**Sử dụng bởi:**
- `student-dashboard.html`
- `student-results.html`
- `student-progress.html`

---

#### `js/quiz.js` - Quiz
**Functions:**

```javascript
// 1. Timer
function startTimer()
function stopTimer()

// 2. Navigation
function goToQuestion(questionNumber)
function nextQuestion()
function previousQuestion()

// 3. Answer selection
function selectAnswer(questionId, answerId)

// 4. Mark for review
function toggleMarkForReview()

// 5. Submit quiz
function submitQuiz()

// 6. Update UI
function updateQuestionDisplay()
function updateNavigationButtons()
function updateProgress()
```

**Sử dụng bởi:**
- `quiz-taking.html`

---

## 🚀 HƯỚNG DẪN CHẠY

### Cách 1: Mở trực tiếp
```
1. Tìm file index.html
2. Double-click
3. Trang sẽ mở trong trình duyệt mặc định
```

### Cách 2: Right-click menu
```
1. Right-click vào index.html
2. Chọn "Open with"
3. Chọn Chrome/Firefox/Safari
```

### Cách 3: Drag & Drop
```
1. Mở trình duyệt
2. Kéo file index.html vào cửa sổ browser
```

### Cách 4: Live Server (nếu có VSCode)
```
1. Install extension "Live Server"
2. Right-click index.html
3. Chọn "Open with Live Server"
4. Trang sẽ tự động reload khi edit code
```

---

## 💻 GIẢI THÍCH CODE

### 1. HTML Basics

#### Structure
```html
<!DOCTYPE html>
<html lang="vi">
  <head>
    <!-- Meta tags, CSS links, Title -->
  </head>
  <body>
    <!-- Header, Main, Footer -->
    <!-- JavaScript ở cuối body -->
  </body>
</html>
```

#### Linking CSS
```html
<!-- External CSS -->
<link rel="stylesheet" href="css/style.css">

<!-- CDN (Tailwind CSS) -->
<script src="https://cdn.tailwindcss.com"></script>
```

#### Linking JavaScript
```html
<!-- External JS -->
<script src="js/main.js"></script>

<!-- Inline JS -->
<script>
  function myFunction() {
    // code here
  }
</script>
```

---

### 2. CSS Basics

#### Selectors
```css
/* Class selector */
.button {
  background: blue;
}

/* ID selector */
#header {
  position: fixed;
}

/* Element selector */
h1 {
  font-size: 2rem;
}
```

#### Animations
```css
/* Define animation */
@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

/* Use animation */
.fade-in {
  animation: fadeIn 0.6s ease;
}
```

#### Responsive
```css
/* Mobile first */
.container {
  width: 100%;
}

/* Desktop */
@media (min-width: 768px) {
  .container {
    width: 80%;
  }
}
```

---

### 3. JavaScript Basics

#### Selecting Elements
```javascript
// By ID
const element = document.getElementById('myId');

// By Class
const elements = document.querySelectorAll('.myClass');

// By Tag
const divs = document.getElementsByTagName('div');
```

#### Event Listeners
```javascript
// Click event
button.addEventListener('click', function() {
  console.log('Clicked!');
});

// Form submit
form.addEventListener('submit', function(e) {
  e.preventDefault(); // Prevent page reload
  // Handle form
});
```

#### DOM Manipulation
```javascript
// Add class
element.classList.add('active');

// Remove class
element.classList.remove('hidden');

// Toggle class
element.classList.toggle('show');

// Change text
element.textContent = 'New text';

// Change HTML
element.innerHTML = '<p>New HTML</p>';
```

---

## ❓ CÂU HỎI THƯỜNG GẶP

### 1. Tại sao tách CSS và JS ra file riêng?

**Lý do:**
- ✅ Code dễ đọc hơn
- ✅ Dễ maintain (bảo trì)
- ✅ Có thể reuse (tái sử dụng)
- ✅ Tách biệt concerns (HTML = structure, CSS = style, JS = behavior)

---

### 2. Tailwind CSS là gì?

**Giải thích:**
- Framework CSS với utility classes
- Thay vì viết CSS riêng, dùng classes có sẵn
- Ví dụ: `bg-blue-600`, `text-white`, `p-4`

**Sử dụng qua CDN:**
```html
<script src="https://cdn.tailwindcss.com"></script>
```

---

### 3. Chart.js hoạt động như thế nào?

**Giải thích:**
- Thư viện JavaScript để vẽ charts
- Sử dụng HTML `<canvas>` element
- Configure bằng JavaScript object

**Example:**
```javascript
new Chart(ctx, {
  type: 'line',
  data: { ... },
  options: { ... }
});
```

---

### 4. Làm sao để edit nội dung?

**Thay đổi text:**
```html
<!-- Tìm trong HTML -->
<h1>Text cũ</h1>

<!-- Đổi thành -->
<h1>Text mới</h1>
```

**Thay đổi màu:**
```css
/* Tìm trong CSS */
.btn-primary {
  background: #2563eb;
}

/* Đổi màu */
.btn-primary {
  background: #dc2626; /* Màu đỏ */
}
```

---

### 5. Responsive design hoạt động thế nào?

**Tailwind breakpoints:**
- `sm:` - ≥ 640px
- `md:` - ≥ 768px
- `lg:` - ≥ 1024px
- `xl:` - ≥ 1280px

**Example:**
```html
<!-- Mobile: 1 column, Desktop: 3 columns -->
<div class="grid grid-cols-1 md:grid-cols-3 gap-4">
  ...
</div>
```

---

## 🎓 KẾT LUẬN

Dự án Scribble là ứng dụng web hoàn chỉnh với:

✅ **Cấu trúc rõ ràng** - Files được tổ chức logic  
✅ **Code sạch** - Có comments và naming convention tốt  
✅ **Chức năng đầy đủ** - Authentication, Quiz, Dashboard, Progress  
✅ **Responsive** - Hoạt động tốt trên mọi thiết bị  
✅ **Dễ hiểu** - Phù hợp cho người mới học  

**Perfect for presentation!** 🎉

---

**Tài liệu này được viết cho mục đích giáo dục**  
**Mọi thắc mắc xin liên hệ qua email**
