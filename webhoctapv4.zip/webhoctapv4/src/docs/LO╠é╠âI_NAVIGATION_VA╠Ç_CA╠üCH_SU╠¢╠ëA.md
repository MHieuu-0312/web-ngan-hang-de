# 🐛 LỖI NAVIGATION VÀ CÁCH SỬA

## ❌ VẤN ĐỀ

Khi click vào các menu trong sidebar của `student-dashboard.html`:
- ❌ Không chuyển được sang `student-practice.html`
- ❌ Không chuyển được sang `student-progress.html`
- ❌ Các trang khác cũng có vấn đề tương tự

---

## 🔍 NGUYÊN NHÂN

### Code LỖI (trước khi sửa):

```html
<!-- SIDEBAR NAVIGATION - SAI -->
<nav class="flex-1 px-4 py-6 space-y-2">
    <a href="#" onclick="showSection('practice')">
        <i class="fas fa-dumbbell mr-3"></i>
        Ôn luyện
    </a>
    <a href="#" onclick="showSection('progress')">
        <i class="fas fa-trophy mr-3"></i>
        Tiến độ
    </a>
</nav>
```

### Giải thích lỗi:

1. **href="#"** 
   - Link không dẫn đến đâu cả
   - Chỉ là placeholder (giữ chỗ)

2. **onclick="showSection('practice')"**
   - Gọi JavaScript function `showSection()`
   - Function này cố gắng ẩn/hiện sections TRONG CÙNG MỘT TRANG
   - Nhưng `student-practice.html` là FILE HTML RIÊNG BIỆT!

3. **Kết quả:**
   - Click vào link → JavaScript chạy
   - JavaScript tìm section 'practice' trong trang hiện tại
   - Không tìm thấy → Không làm gì cả
   - Trang KHÔNG chuyển đi!

---

## ✅ CÁCH SỬA

### Code ĐÚNG (sau khi sửa):

```html
<!-- SIDEBAR NAVIGATION - ĐÚNG -->
<nav class="flex-1 px-4 py-6 space-y-2">
    <a href="student-dashboard.html">
        <i class="fas fa-home mr-3"></i>
        Tổng quan
    </a>
    <a href="student-quizzes.html">
        <i class="fas fa-clipboard-list mr-3"></i>
        Bài kiểm tra
    </a>
    <a href="student-practice.html">
        <i class="fas fa-dumbbell mr-3"></i>
        Ôn luyện
    </a>
    <a href="student-results.html">
        <i class="fas fa-chart-bar mr-3"></i>
        Kết quả
    </a>
    <a href="student-progress.html">
        <i class="fas fa-trophy mr-3"></i>
        Tiến độ
    </a>
</nav>
```

### Giải thích sửa lỗi:

1. **Đổi href="#" → href="student-practice.html"**
   - Link giờ dẫn đến file HTML thực tế
   - Browser sẽ tải trang mới khi click

2. **Xóa onclick="showSection()"**
   - Không cần JavaScript
   - Để browser xử lý navigation tự nhiên

3. **Kết quả:**
   - Click vào link → Browser tải file HTML mới
   - Trang chuyển thành công! ✅

---

## 🎓 GIẢI THÍCH CHO GIÁO SƯ

### Hai cách navigation trong Web:

#### 1️⃣ **Multi-Page Application (MPA)** - Như dự án này
```
student-dashboard.html
student-practice.html    ← Files riêng biệt
student-progress.html

Khi click link → Browser tải file HTML mới
```

**Ưu điểm:**
- ✅ Đơn giản, dễ hiểu
- ✅ Không cần JavaScript phức tạp
- ✅ Mỗi trang độc lập
- ✅ Phù hợp cho người mới học

**Navigation:**
```html
<a href="other-page.html">Link to other page</a>
```

---

#### 2️⃣ **Single-Page Application (SPA)** - Không dùng ở đây
```
index.html  ← Chỉ 1 file HTML
├── Section: Dashboard
├── Section: Practice     ← Ẩn/hiện bằng JavaScript
└── Section: Progress

Khi click → JavaScript ẩn/hiện sections
```

**Navigation:**
```html
<a href="#" onclick="showSection('practice')">
    Practice
</a>

<script>
function showSection(name) {
    // Ẩn tất cả sections
    // Hiện section được chọn
}
</script>
```

**Khi nào dùng:**
- Ứng dụng React, Vue, Angular
- Cần tốc độ cao (không reload trang)
- Có nhiều JavaScript logic

---

## 🔧 CÁCH KIỂM TRA

### Test navigation:

1. **Mở `student-dashboard.html`**
   ```
   Double-click file trong folder
   ```

2. **Click vào "Ôn luyện" trong sidebar**
   ```
   → Nên chuyển sang student-practice.html
   → URL bar thay đổi
   → Trang mới tải lên
   ```

3. **Click vào "Tiến độ"**
   ```
   → Nên chuyển sang student-progress.html
   → URL bar thay đổi
   → Trang mới tải lên
   ```

### Dấu hiệu lỗi:

❌ **Nếu vẫn lỗi:**
- URL không thay đổi
- Trang không load mới
- Không có gì xảy ra khi click

✅ **Nếu đã sửa đúng:**
- URL thay đổi (ví dụ: từ `...student-dashboard.html` → `...student-practice.html`)
- Trang load mới
- Thấy nội dung của trang mới

---

## 💡 BÀI HỌC

### 1. Hiểu rõ cấu trúc project

**Multi-page:**
- Nhiều file HTML
- Mỗi file = 1 trang
- Dùng `<a href="file.html">`

**Single-page:**
- 1 file HTML
- Nhiều sections ẩn/hiện
- Dùng JavaScript

### 2. href vs onclick

```html
<!-- NAVIGATION giữa các trang -->
<a href="other-page.html">Go to other page</a>

<!-- ACTION trong cùng trang -->
<a href="#" onclick="doSomething()">Do action</a>
```

### 3. Debug navigation issues

**Bước 1:** Kiểm tra URL
- Có thay đổi không?
- Đúng file name không?

**Bước 2:** Kiểm tra HTML
- href có đúng không?
- File có tồn tại không?

**Bước 3:** Kiểm tra Browser Console (F12)
- Có lỗi JavaScript không?
- 404 errors (file not found)?

---

## 📝 CHECKLIST SỬA LỖI

Khi sửa navigation issues:

- [ ] Xác định project type (MPA hay SPA)
- [ ] Check href có trỏ đến file đúng
- [ ] Xóa onclick không cần thiết
- [ ] Test tất cả links
- [ ] Verify URL changes
- [ ] Check browser console errors

---

## 🎯 KẾT LUẬN

### Lỗi gốc:
```
Nhầm lẫn giữa MPA và SPA navigation
→ Dùng JavaScript showSection() cho MPA
→ Không hoạt động vì files riêng biệt
```

### Cách sửa:
```
Đổi href="#" → href="file-name.html"
Xóa onclick="showSection()"
→ Dùng HTML navigation thông thường
```

### Bài học:
```
✅ Hiểu rõ cấu trúc project
✅ Chọn navigation method phù hợp
✅ Test kỹ trước khi deploy
```

---

**Tài liệu này giải thích:**
- ✅ Lỗi là gì
- ✅ Tại sao lỗi
- ✅ Cách sửa
- ✅ Cách tránh lỗi tương tự

**Phù hợp cho:**
- 👨‍🎓 Sinh viên học web development
- 👨‍🏫 Giáo sư review code
- 🔧 Developer debug issues

---

**Created:** 2025  
**Topic:** Web Navigation Best Practices  
**Level:** Beginner-Intermediate
