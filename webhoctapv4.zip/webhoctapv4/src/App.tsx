import { Header } from "./components/Header";
import { HeroSection } from "./components/HeroSection";
import { FeaturesSection } from "./components/FeaturesSection";
import { HowItWorksSection } from "./components/HowItWorksSection";
import { ForYouSection } from "./components/ForYouSection";
import { TestimonialsSection } from "./components/TestimonialsSection";
import { Footer } from "./components/Footer";

export default function App() {
  // Images from Unsplash
  const images = {
    hero: "https://images.unsplash.com/photo-1748665194498-21a7e3d8ff19?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjB3b3Jrc3BhY2UlMjBsYXB0b3B8ZW58MXx8fHwxNzU5MzgwMjk1fDA&ixlib=rb-4.1.0&q=80&w=1080",
    questionBank:
      "https://images.unsplash.com/photo-1662120455989-5a433cec9980?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxxdWVzdGlvbiUyMG1hcmslMjBxdWl6fGVufDF8fHx8MTc1OTQ4NDY0Nnww&ixlib=rb-4.1.0&q=80&w=1080",
    testCreation:
      "https://images.unsplash.com/photo-1614492898637-435e0f87cef8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaWdpdGFsJTIwdGVzdCUyMGV4YW18ZW58MXx8fHwxNzU5NDg0NjQ3fDA&ixlib=rb-4.1.0&q=80&w=1080",
    analytics:
      "https://images.unsplash.com/photo-1748609160056-7b95f30041f0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbmFseXRpY3MlMjBkYXNoYm9hcmQlMjBjaGFydHxlbnwxfHx8fDE3NTk0ODQ2NDd8MA&ixlib=rb-4.1.0&q=80&w=1080",
    teacher:
      "https://images.unsplash.com/photo-1543269664-76bc3997d9ea?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWFjaGVyJTIwY2xhc3Nyb29tJTIwdGVjaG5vbG9neXxlbnwxfHx8fDE3NTk0NDkzOTB8MA&ixlib=rb-4.1.0&q=80&w=1080",
    student:
      "https://images.unsplash.com/photo-1596247290824-e9f12b8c574f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50JTIwc3R1ZHlpbmclMjBvbmxpbmV8ZW58MXx8fHwxNzU5NDc4MDUyfDA&ixlib=rb-4.1.0&q=80&w=1080",
  };

  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <HeroSection heroImage={images.hero} />
        <FeaturesSection
          images={{
            questionBank: images.questionBank,
            testCreation: images.testCreation,
            analytics: images.analytics,
          }}
        />
        <HowItWorksSection />
        <ForYouSection
          teacherImage={images.teacher}
          studentImage={images.student}
        />
        <TestimonialsSection />
      </main>
      <Footer />
    </div>
  );
}