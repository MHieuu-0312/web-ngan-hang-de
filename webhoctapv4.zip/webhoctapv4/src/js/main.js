/**
 * SCRIBBLE APP - MAIN JAVASCRIPT
 * JavaScript chung cho toàn bộ ứng dụng
 */

// ==========================================
// MOBILE MENU
// ==========================================
function toggleMobileMenu() {
    const mobileMenu = document.getElementById('mobileMenu');
    if (mobileMenu) {
        mobileMenu.classList.toggle('active');
    }
}

// ==========================================
// HEADER SCROLL EFFECT
// ==========================================
window.addEventListener('scroll', function() {
    const header = document.getElementById('mainHeader');
    const loginBtn = document.getElementById('loginBtn');
    
    if (!header) return;
    
    if (window.scrollY > 50) {
        header.classList.add('header-scrolled');
        header.classList.remove('header-transparent');
        
        if (loginBtn) {
            loginBtn.style.borderColor = '#d1d5db';
            loginBtn.style.color = '#374151';
        }
    } else {
        header.classList.remove('header-scrolled');
        header.classList.add('header-transparent');
        
        if (loginBtn) {
            loginBtn.style.borderColor = 'white';
            loginBtn.style.color = 'white';
        }
    }
});

// ==========================================
// TAB SWITCHING (For You Section)
// ==========================================
function switchTab(tab) {
    // Buttons
    const studentTab = document.getElementById('studentTab');
    const studentContent = document.getElementById('studentContent');
    
    if (!studentTab || !studentContent) return;
    
    // Student tab is always active (no teacher)
    studentTab.classList.add('bg-blue-600', 'text-white', 'shadow-md');
    studentTab.classList.remove('text-gray-600');
    studentContent.classList.add('active');
}

// ==========================================
// TESTIMONIALS CAROUSEL
// ==========================================
let currentTestimonial = 0;

function showTestimonial(index) {
    const testimonials = document.querySelectorAll('.testimonial-item');
    const indicators = document.querySelectorAll('.testimonial-indicator');
    
    if (testimonials.length === 0) return;
    
    // Hide all testimonials
    testimonials.forEach((item, i) => {
        item.classList.remove('active');
        if (i === index) {
            item.classList.add('active');
        }
    });
    
    // Update indicators
    indicators.forEach((indicator, i) => {
        if (i === index) {
            indicator.classList.add('bg-blue-600', 'w-8');
            indicator.classList.remove('bg-gray-300');
        } else {
            indicator.classList.remove('bg-blue-600', 'w-8');
            indicator.classList.add('bg-gray-300');
        }
    });
    
    currentTestimonial = index;
}

// Auto-rotate testimonials every 5 seconds
function startTestimonialCarousel() {
    const testimonials = document.querySelectorAll('.testimonial-item');
    if (testimonials.length === 0) return;
    
    setInterval(() => {
        currentTestimonial = (currentTestimonial + 1) % testimonials.length;
        showTestimonial(currentTestimonial);
    }, 5000);
}

// ==========================================
// SCROLL REVEAL ANIMATION
// ==========================================
function reveal() {
    const reveals = document.querySelectorAll('.reveal');
    
    reveals.forEach(element => {
        const windowHeight = window.innerHeight;
        const elementTop = element.getBoundingClientRect().top;
        const elementVisible = 150;
        
        if (elementTop < windowHeight - elementVisible) {
            element.classList.add('active');
        }
    });
}

window.addEventListener('scroll', reveal);

// ==========================================
// SMOOTH SCROLLING
// ==========================================
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        const href = this.getAttribute('href');
        
        if (href !== '#' && href !== '#!') {
            e.preventDefault();
            const target = document.querySelector(href);
            
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
                
                // Close mobile menu if open
                const mobileMenu = document.getElementById('mobileMenu');
                if (mobileMenu) {
                    mobileMenu.classList.remove('active');
                }
            }
        }
    });
});

// ==========================================
// INITIALIZE ON PAGE LOAD
// ==========================================
document.addEventListener('DOMContentLoaded', function() {
    // Initialize scroll reveal
    reveal();
    
    // Start testimonial carousel if on home page
    if (document.querySelectorAll('.testimonial-item').length > 0) {
        startTestimonialCarousel();
    }
    
    console.log('Scribble App initialized successfully!');
});
