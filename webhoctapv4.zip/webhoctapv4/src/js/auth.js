/**
 * AUTHENTICATION JAVASCRIPT
 * Login & Signup functionality
 */

// ==========================================
// FORM VALIDATION
// ==========================================

/**
 * Validate email format
 */
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

/**
 * Validate password (min 6 characters)
 */
function validatePassword(password) {
    return password.length >= 6;
}

/**
 * Show error message
 */
function showError(inputId, message) {
    const input = document.getElementById(inputId);
    const errorDiv = document.getElementById(inputId + 'Error');
    
    if (input) {
        input.classList.add('error');
    }
    
    if (errorDiv) {
        errorDiv.textContent = message;
        errorDiv.classList.add('show');
    }
}

/**
 * Clear error message
 */
function clearError(inputId) {
    const input = document.getElementById(inputId);
    const errorDiv = document.getElementById(inputId + 'Error');
    
    if (input) {
        input.classList.remove('error');
    }
    
    if (errorDiv) {
        errorDiv.classList.remove('show');
    }
}

// ==========================================
// LOGIN HANDLER
// ==========================================
function handleLogin(event) {
    event.preventDefault();
    
    // Get form values
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    // Clear previous errors
    clearError('email');
    clearError('password');
    
    // Validate
    let isValid = true;
    
    if (!email) {
        showError('email', 'Vui lòng nhập email');
        isValid = false;
    } else if (!validateEmail(email)) {
        showError('email', 'Email không hợp lệ');
        isValid = false;
    }
    
    if (!password) {
        showError('password', 'Vui lòng nhập mật khẩu');
        isValid = false;
    }
    
    if (isValid) {
        // In real app, this would call API
        console.log('Login successful:', { email, password });
        
        // Redirect to student dashboard
        window.location.href = 'student-dashboard.html';
    }
    
    return false;
}

// ==========================================
// SIGNUP HANDLER
// ==========================================
function handleSignup(event) {
    event.preventDefault();
    
    // Get form values
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const terms = document.getElementById('terms').checked;
    
    // Clear previous errors
    clearError('name');
    clearError('email');
    clearError('password');
    clearError('confirmPassword');
    
    // Validate
    let isValid = true;
    
    if (!name) {
        showError('name', 'Vui lòng nhập họ tên');
        isValid = false;
    }
    
    if (!email) {
        showError('email', 'Vui lòng nhập email');
        isValid = false;
    } else if (!validateEmail(email)) {
        showError('email', 'Email không hợp lệ');
        isValid = false;
    }
    
    if (!password) {
        showError('password', 'Vui lòng nhập mật khẩu');
        isValid = false;
    } else if (!validatePassword(password)) {
        showError('password', 'Mật khẩu phải có ít nhất 6 ký tự');
        isValid = false;
    }
    
    if (password !== confirmPassword) {
        showError('confirmPassword', 'Mật khẩu không khớp');
        isValid = false;
    }
    
    if (!terms) {
        alert('Vui lòng đồng ý với điều khoản sử dụng');
        isValid = false;
    }
    
    if (isValid) {
        // In real app, this would call API
        console.log('Signup successful:', { name, email });
        
        // Redirect to student dashboard
        window.location.href = 'student-dashboard.html';
    }
    
    return false;
}

// ==========================================
// TOGGLE PASSWORD VISIBILITY
// ==========================================
function togglePassword(inputId) {
    const input = document.getElementById(inputId);
    const icon = input.nextElementSibling;
    
    if (input.type === 'password') {
        input.type = 'text';
        if (icon) icon.classList.replace('fa-eye', 'fa-eye-slash');
    } else {
        input.type = 'password';
        if (icon) icon.classList.replace('fa-eye-slash', 'fa-eye');
    }
}
